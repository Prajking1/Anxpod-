import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import GPUTemplatesPage from "@/react-app/pages/GPUTemplates";
import GPUInstancesPage from "@/react-app/pages/GPUInstances";
import BareMetalPage from "@/react-app/pages/BareMetal";
import OpenSourceInferencingPage from "@/react-app/pages/OpenSourceInferencing";
import HuggingFacePage from "@/react-app/pages/HuggingFace";
import NvidiaNimPage from "@/react-app/pages/NvidianNim";
import FineTuningPage from "@/react-app/pages/FineTuning";
import RAGPage from "@/react-app/pages/RAG";
import DashboardPage from "@/react-app/pages/Dashboard";
import MyFilesPage from "@/react-app/pages/MyFiles";
import AIControllerPage from "@/react-app/pages/AIController";
import DocsPage from "@/react-app/pages/Docs";
import RequestAccessPage from "@/react-app/pages/RequestAccess";
import PricingPage from "@/react-app/pages/Pricing";
import SignUpPage from "@/react-app/pages/SignUp";
import LoginPage from "@/react-app/pages/Login";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/gpu-compute/templates" element={<GPUTemplatesPage />} />
        <Route path="/gpu-compute/instances" element={<GPUInstancesPage />} />
        <Route path="/gpu-compute/bare-metal" element={<BareMetalPage />} />
        <Route path="/llm-tools/inferencing/open-source" element={<OpenSourceInferencingPage />} />
        <Route path="/llm-tools/inferencing/hugging-face" element={<HuggingFacePage />} />
        <Route path="/llm-tools/inferencing/nvidia-nim" element={<NvidiaNimPage />} />
        <Route path="/llm-tools/fine-tuning" element={<FineTuningPage />} />
        <Route path="/llm-tools/rag" element={<RAGPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/my-files" element={<MyFilesPage />} />
        <Route path="/ai-controller" element={<AIControllerPage />} />
        <Route path="/docs" element={<DocsPage />} />
        <Route path="/request-access" element={<RequestAccessPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/login" element={<LoginPage />} />
      </Routes>
    </Router>
  );
}
