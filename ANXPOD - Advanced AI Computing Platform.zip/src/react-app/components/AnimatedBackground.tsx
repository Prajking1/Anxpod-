import { useEffect, useRef } from 'react';

export default function AnimatedBackground() {
  const backgroundRef = useRef<HTMLDivElement>(null);
  const mousePosition = useRef({ x: 0, y: 0 });
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mousePosition.current = {
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100,
      };
    };

    const animateBackground = () => {
      if (backgroundRef.current) {
        const { x, y } = mousePosition.current;
        
        // Subtle gradient shift based on mouse position
        const offsetX = (x - 50) * 0.05; // Reduced intensity
        const offsetY = (y - 50) * 0.05;
        
        backgroundRef.current.style.transform = `translate3d(${offsetX}px, ${offsetY}px, 0) scale(1.02)`;
      }
      rafRef.current = requestAnimationFrame(animateBackground);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    rafRef.current = requestAnimationFrame(animateBackground);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  return (
    <>
      {/* Main Tron-style gradient background */}
      <div
        ref={backgroundRef}
        className="fixed inset-0 w-screen h-screen z-[-2] will-change-transform"
        style={{
          background: `
            radial-gradient(circle at 25% 25%, #1F6BFF 0%, transparent 50%),
            radial-gradient(circle at 75% 75%, #00E5FF 0%, transparent 50%),
            linear-gradient(135deg, #000000 0%, #0B0F14 25%, #0E1726 50%, #111827 100%)
          `,
          transition: 'transform 0.2s ease-out',
        }}
      />
      
      {/* Tron ambient overlay */}
      <div
        className="fixed inset-0 w-screen h-screen z-[-1]"
        style={{
          background: 'radial-gradient(circle, rgba(0,255,255,0.08) 0%, rgba(0,255,255,0.00) 60%)'
        }}
      />

      {/* Subtle cyan accent shapes */}
      <div className="fixed inset-0 w-screen h-screen z-[-1] overflow-hidden pointer-events-none">
        <div
          className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-10"
          style={{
            background: 'radial-gradient(circle, rgba(0, 229, 255, 0.12) 0%, transparent 70%)',
          }}
        />
        
        <div
          className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full opacity-8"
          style={{
            background: 'radial-gradient(circle, rgba(31, 107, 255, 0.08) 0%, transparent 70%)',
          }}
        />

        <div
          className="absolute top-1/2 right-1/3 w-64 h-64 rounded-full opacity-6"
          style={{
            background: 'radial-gradient(circle, rgba(102, 230, 255, 0.06) 0%, transparent 70%)',
          }}
        />
      </div>

      {/* Content readability overlay */}
      <div className="fixed inset-0 w-screen h-screen z-[-1] bg-black/20" />
    </>
  );
}
