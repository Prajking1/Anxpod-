import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { 
  Home, 
  BarChart3, 
  FileText, 
  LogIn, 
  ChevronDown,
  Menu,
  X,
  CircuitBoard,
  Bot,
  Sparkles,
  Database,
  Layers
} from 'lucide-react';
import AnimatedBackground from './AnimatedBackground';

interface LayoutProps {
  children: React.ReactNode;
}

const sidebarItems = [
  { name: 'Home', icon: Home, path: '/', highlighted: true },
  { 
    name: 'GPU Compute', 
    icon: CircuitBoard, 
    path: '/gpu-compute',
    submenu: [
      { name: 'A/ML Templates', path: '/gpu-compute/templates' },
      { name: 'GPU Instances', path: '/gpu-compute/instances' },
      { name: 'Bare Metal', path: '/gpu-compute/bare-metal' }
    ]
  },
  { 
    name: 'LLM Tools', 
    icon: Bot, 
    path: '/llm-tools',
    submenu: [
      { 
        name: 'Inferencing', 
        submenu: [
          { name: 'Open Source', path: '/llm-tools/inferencing/open-source' },
          { name: 'Hugging Face', path: '/llm-tools/inferencing/hugging-face' },
          { name: 'NVIDIA NIM', path: '/llm-tools/inferencing/nvidia-nim' }
        ]
      },
      { name: 'Fine Tuning', path: '/llm-tools/fine-tuning' },
      { name: 'RAG', path: '/llm-tools/rag' }
    ]
  },
  { name: 'Dashboard', icon: BarChart3, path: '/dashboard' },
  { name: 'My Files', icon: Database, path: '/my-files' },
  { name: 'AI Controller', icon: Sparkles, path: '/ai-controller' },
  { name: 'Docs', icon: FileText, path: '/docs' },
];

export default function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [openMenus, setOpenMenus] = useState<string[]>([]);
  const location = useLocation();

  // Handle responsive behavior
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setSidebarOpen(false);
        setSidebarCollapsed(false);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Auto-open menus based on current path
  useEffect(() => {
    const currentPath = location.pathname;
    
    // Open GPU Compute menu if on GPU routes
    if (currentPath.startsWith('/gpu-compute') && !openMenus.includes('GPU Compute')) {
      setOpenMenus(prev => [...prev, 'GPU Compute']);
    }
    
    // Open LLM Tools menu if on LLM routes
    if (currentPath.startsWith('/llm-tools') && !openMenus.includes('LLM Tools')) {
      setOpenMenus(prev => [...prev, 'LLM Tools']);
    }
  }, [location.pathname, openMenus]);

  const toggleMenu = (name: string) => {
    setOpenMenus(prev => 
      prev.includes(name) 
        ? prev.filter(item => item !== name)
        : [...prev, name]
    );
  };

  const isActiveItem = (item: any) => {
    if (item.path) {
      return location.pathname === item.path || location.pathname.startsWith(item.path + '/');
    }
    if (item.submenu) {
      // Recursively check if any sub-item or nested sub-item is active
      return item.submenu.some((sub: any) => isActiveItem(sub));
    }
    return false;
  };

  return (
    <div className="min-h-screen text-primaryText font-poppins relative">
      <AnimatedBackground />
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-tronSurface3/95 backdrop-blur-xl border-b border-tronBorder">
        <div className="flex items-center justify-between px-6 py-4">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-tronTextPrimary"
            >
              {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-tron-gradient rounded-lg flex items-center justify-center shadow-tron-shadow-1">
                <div className="w-4 h-4 bg-white rounded-sm transform rotate-45"></div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-tronTextPrimary">ANXPOD</h1>
                <p className="text-xs text-tronTextMuted">Advanced AI Computing Platform</p>
              </div>
            </Link>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            <Link to="/request-access">
              <button className="px-4 py-2 bg-tron-gradient rounded-lg text-tronTextPrimary font-medium shadow-tron-shadow-1">
                Request Free Access
              </button>
            </Link>
            <Link to="/pricing">
              <button className="px-4 py-2 bg-tronSurface2 border border-tronBorder rounded-lg text-tronTextPrimary font-medium">
                Pricing
              </button>
            </Link>
            <Link to="/signup">
              <button className="px-4 py-2 bg-tron-gradient rounded-lg text-tronTextPrimary font-medium shadow-tron-shadow-1">
                Sign Up
              </button>
            </Link>
            <Link to="/login" className="text-tronTextSecondary font-medium">
              Login
            </Link>
          </nav>
        </div>
      </header>

      <div className="flex pt-20">
        {/* Sidebar */}
        <aside
          className="fixed top-20 left-0 bottom-0 h-screen bg-tronSurface1/95 backdrop-blur-xl border-r border-tronBorder z-40 overflow-y-auto scrollbar-hide"
          style={{ 
            transform: (sidebarOpen || !isMobile) ? 'translateX(0)' : 'translateX(-280px)',
            width: sidebarCollapsed && !isMobile ? '64px' : '280px',
            transition: 'all 0.2s ease-in-out'
          }}
        >
          {/* Sidebar Header */}
          <div className="p-4 border-b border-tronBorder">
            <div className="flex items-center justify-between">
              {!sidebarCollapsed && (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-tron-gradient rounded-lg flex items-center justify-center shadow-tron-shadow-1">
                    <Layers className="text-white" size={16} />
                  </div>
                  <span className="text-tronTextPrimary font-semibold text-sm">ANXPOD</span>
                </div>
              )}
              <button
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className="p-1 text-tronTextMuted bg-tronSurface2 rounded-lg"
              >
                <Menu size={16} />
              </button>
            </div>
          </div>

          <nav className="p-3 space-y-1">
            {sidebarItems.map((item) => (
              <div key={item.name}>
                {!item.submenu ? (
                  <Link
                    to={item.path}
                    onClick={() => isMobile && setSidebarOpen(false)}
                  >
                    <div className={`flex items-center p-3 rounded-xl cursor-pointer ${
                        isActiveItem(item)
                          ? 'bg-tronAccent/20 text-tronAccent border-l-4 border-tronAccent'
                          : 'text-tronTextSecondary'
                      }`}>
                      <div className={`p-2 rounded-lg ${
                        isActiveItem(item) 
                          ? 'bg-tronAccent/20 text-tronAccent' 
                          : 'text-tronTextMuted'
                      }`}>
                        <item.icon size={18} />
                      </div>
                      {!sidebarCollapsed && (
                        <span className="font-medium text-body-sm ml-3">
                          {item.name}
                        </span>
                      )}
                    </div>
                  </Link>
                ) : (
                  <div>
                    <div
                      className={`flex items-center p-3 rounded-xl cursor-pointer ${
                        isActiveItem(item)
                          ? 'bg-tronAccent/20 text-tronAccent border-l-4 border-tronAccent'
                          : 'text-tronTextSecondary'
                      }`}
                      onClick={(e) => {
                        e.preventDefault();
                        if (!sidebarCollapsed) toggleMenu(item.name);
                      }}
                    >
                      <div className={`p-2 rounded-lg ${
                        isActiveItem(item) 
                          ? 'bg-tronAccent/20 text-tronAccent' 
                          : 'text-tronTextMuted'
                      }`}>
                        <item.icon size={18} />
                      </div>
                      {!sidebarCollapsed && (
                        <span className="font-medium text-sm ml-3">
                          {item.name}
                        </span>
                      )}
                      {!sidebarCollapsed && (
                        <ChevronDown 
                          size={14} 
                          className={`ml-auto transition-transform ${
                            openMenus.includes(item.name) ? 'rotate-180' : ''
                          }`}
                        />
                      )}
                    </div>
                    
                    {/* Submenu */}
                    {!sidebarCollapsed && item.submenu && openMenus.includes(item.name) && (
                      <div className="ml-6 mt-1 space-y-1 border-l border-tronBorder pl-4">
                        {item.submenu.map((subItem) => (
                          <div key={subItem.name}>
                            <Link
                              to={subItem.path}
                              onClick={() => isMobile && setSidebarOpen(false)}
                              className={`block p-2 rounded-lg text-sm ${
                                isActiveItem(subItem)
                                  ? 'bg-tronAccent/20 text-tronAccent border-l-2 border-tronAccent pl-3'
                                  : 'text-tronTextSecondary'
                              }`}
                            >
                              {subItem.name}
                            </Link>
                            {/* Nested submenu */}
                            {subItem.submenu && (
                              <div className="ml-4 mt-1 space-y-1 border-l border-tronBorder pl-3">
                                {subItem.submenu.map((nestedItem) => (
                                  <Link
                                    key={nestedItem.name}
                                    to={nestedItem.path}
                                    onClick={() => isMobile && setSidebarOpen(false)}
                                    className={`block p-2 rounded-lg text-xs ${
                                      isActiveItem(nestedItem)
                                        ? 'bg-tronAccent/20 text-tronAccent border-l-2 border-tronAccent pl-3'
                                        : 'text-tronTextSecondary'
                                    }`}
                                  >
                                    {nestedItem.name}
                                  </Link>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
            
            {/* Login at bottom */}
            <div className="pt-6 mt-6 border-t border-tronBorder">
              <Link
                to="/login"
                onClick={() => isMobile && setSidebarOpen(false)}
              >
                <div className="flex items-center p-3 rounded-xl text-tronTextSecondary">
                  <div className="p-2 rounded-lg text-tronTextMuted">
                    <LogIn size={18} />
                  </div>
                  {!sidebarCollapsed && (
                    <span className="font-medium text-sm ml-3">Login</span>
                  )}
                </div>
              </Link>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main 
          className="flex-1"
          style={{ 
            marginLeft: !isMobile ? (sidebarCollapsed ? '64px' : '280px') : '0px',
            transition: 'margin-left 0.2s ease-in-out'
          }}
        >
          <div className="min-h-screen">
            {children}
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-tronSurface1/95 border-t border-tronBorder py-6">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-tronTextMuted text-sm">
              Copyright © 2025 ANXPOD - Advanced AI Computing Platform
            </p>
            <div className="flex gap-system-lg mt-4 md:mt-0">
              <Link to="/about" className="text-tronTextMuted text-sm hover:text-tronLink">About</Link>
              <Link to="/contact" className="text-tronTextMuted text-sm hover:text-tronLink">Contact</Link>
              <Link to="/terms" className="text-tronTextMuted text-sm hover:text-tronLink">Terms & conditions</Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && isMobile && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
