import { ReactNode, forwardRef } from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  variant?: 'default' | 'filled';
  inputSize?: 'sm' | 'md' | 'lg';
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ 
    label, 
    error, 
    helperText, 
    leftIcon, 
    rightIcon, 
    variant = 'default', 
    inputSize = 'md',
    className = '', 
    ...props 
  }, ref) => {
    const baseClasses = 'w-full transition-all duration-150 ease-out focus:outline-none focus:shadow-tron-focus';
    
    const variantClasses = {
      default: 'bg-tronSurface2 border border-tronBorder hover:border-tronFocusOuter focus:border-tronFocusOuter',
      filled: 'bg-tronSurface3 border border-transparent hover:bg-tronSurface2 focus:bg-tronSurface2 focus:border-tronFocusOuter'
    };

    const sizeClasses = {
      sm: 'px-3 py-2 text-body-sm rounded-md',
      md: 'px-4 py-2.5 text-body-sm rounded-lg',
      lg: 'px-4 py-3 text-body rounded-lg'
    };

    const errorClasses = error 
      ? 'border-red-500/50 focus:border-red-500' 
      : '';

    const inputClasses = `
      ${baseClasses}
      ${variantClasses[variant]}
      ${sizeClasses[inputSize]}
      ${errorClasses}
      ${leftIcon ? 'pl-10' : ''}
      ${rightIcon ? 'pr-10' : ''}
      text-tronTextPrimary placeholder-tronTextMuted
      ${className}
    `;

    return (
      <div className="space-y-1">
        {label && (
          <label className="block text-body-sm font-medium text-tronTextSecondary">
            {label}
          </label>
        )}
        
        <div className="relative">
          {leftIcon && (
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-tronTextMuted">
              {leftIcon}
            </div>
          )}
          
          <input
            ref={ref}
            className={inputClasses}
            {...props}
          />
          
          {rightIcon && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-tronTextMuted">
              {rightIcon}
            </div>
          )}
        </div>
        
        {(error || helperText) && (
          <p className={`text-body-xs ${error ? 'text-red-400' : 'text-tronTextMuted'}`}>
            {error || helperText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

export default Input;
