import { ReactNode } from 'react';

interface TableProps {
  children: ReactNode;
  className?: string;
}

interface TableHeaderProps {
  children: ReactNode;
  className?: string;
}

interface TableBodyProps {
  children: ReactNode;
  className?: string;
}

interface TableRowProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

interface TableCellProps {
  children: ReactNode;
  className?: string;
  header?: boolean;
}

export function Table({ children, className = '' }: TableProps) {
  return (
    <div className={`overflow-hidden rounded-lg border border-white/[0.08] bg-white/[0.02] ${className}`}>
      <div className="overflow-x-auto">
        <table className="w-full">
          {children}
        </table>
      </div>
    </div>
  );
}

export function TableHeader({ children, className = '' }: TableHeaderProps) {
  return (
    <thead className={`bg-white/[0.02] border-b border-white/[0.08] ${className}`}>
      {children}
    </thead>
  );
}

export function TableBody({ children, className = '' }: TableBodyProps) {
  return (
    <tbody className={className}>
      {children}
    </tbody>
  );
}

export function TableRow({ children, className = '', hover = true }: TableRowProps) {
  const hoverClasses = hover 
    ? 'hover:bg-white/[0.02] transition-colors duration-150 ease-out' 
    : '';

  return (
    <tr className={`border-b border-white/[0.05] last:border-0 ${hoverClasses} ${className}`}>
      {children}
    </tr>
  );
}

export function TableCell({ children, className = '', header = false }: TableCellProps) {
  const baseClasses = 'px-4 py-3 text-left';
  const headerClasses = header 
    ? 'text-body-xs font-medium text-gray-400 uppercase tracking-wider bg-white/[0.01]' 
    : 'text-body-sm text-gray-300';

  return (
    <td className={`${baseClasses} ${headerClasses} ${className}`}>
      {children}
    </td>
  );
}

// Export as default for convenience
export default {
  Root: Table,
  Header: TableHeader,
  Body: TableBody,
  Row: TableRow,
  Cell: TableCell
};
