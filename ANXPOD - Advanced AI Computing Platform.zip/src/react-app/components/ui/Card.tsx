import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'outlined' | 'ghost';
  padding?: 'sm' | 'md' | 'lg';
}

export default function Card({ 
  children, 
  className = '', 
  variant = 'default',
  padding = 'md'
}: CardProps) {
  const baseClasses = 'rounded-lg';
  
  const variantClasses = {
    default: 'bg-tronSurface1 border border-tronBorder shadow-tron-shadow-1',
    outlined: 'bg-transparent border border-tronBorder',
    ghost: 'bg-tronSurface1/50 border border-transparent'
  };

  const paddingClasses = {
    sm: 'p-system-sm',
    md: 'p-system-md',
    lg: 'p-system-lg'
  };

  return (
    <div
      className={`
        ${baseClasses}
        ${variantClasses[variant]}
        ${paddingClasses[padding]}
        ${className}
      `}
    >
      {children}
    </div>
  );
}
