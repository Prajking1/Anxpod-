import { motion } from 'framer-motion';
import { Search, Filter, Star, Zap, Code, Image, MessageSquare, Eye, Brain, Cpu, Shield } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const nvidiaModels = [
  {
    name: 'Llama-3.1-405B-Instruct',
    type: 'Language Model',
    performance: 'Ultra High',
    icon: MessageSquare,
    price: '$0.50',
    description: 'Meta\'s largest and most capable language model optimized with NVIDIA NIM',
    specs: '405B parameters, Multi-modal'
  },
  {
    name: 'Llama-3.1-70B-Instruct',
    type: 'Language Model', 
    performance: 'High',
    icon: MessageSquare,
    price: '$0.15',
    description: 'High-performance instruction-following model with NVIDIA acceleration',
    specs: '70B parameters, Code & Reasoning'
  },
  {
    name: 'Llama-3.1-8B-Instruct',
    type: 'Language Model',
    performance: 'Medium',
    icon: MessageSquare,
    price: '$0.05',
    description: 'Efficient and fast language model for general use cases',
    specs: '8B parameters, Multi-lingual'
  },
  {
    name: 'Mistral-7B-Instruct-v0.3',
    type: 'Language Model',
    performance: 'Medium',
    icon: MessageSquare,
    price: '$0.04',
    description: 'Mistral AI\'s instruction-tuned model with NVIDIA optimization',
    specs: '7B parameters, Fast inference'
  },
  {
    name: 'CodeLlama-34B-Instruct',
    type: 'Code Generation',
    performance: 'High',
    icon: Code,
    price: '$0.12',
    description: 'Specialized code generation model with NVIDIA acceleration',
    specs: '34B parameters, Multi-language coding'
  },
  {
    name: 'Stable-Diffusion-XL-Base-1.0',
    type: 'Image Generation',
    performance: 'High',
    icon: Image,
    price: '$0.08',
    description: 'High-resolution image generation with NVIDIA TensorRT optimization',
    specs: '1024x1024, Fast generation'
  },
  {
    name: 'SDXL-Turbo',
    type: 'Image Generation',
    performance: 'Ultra High',
    icon: Image,
    price: '$0.06',
    description: 'Ultra-fast image generation in real-time with NVIDIA optimization',
    specs: 'Single-step generation, Real-time'
  },
  {
    name: 'Whisper-Large-V3',
    type: 'Speech Recognition',
    performance: 'High',
    icon: MessageSquare,
    price: '$0.03',
    description: 'Advanced speech recognition with NVIDIA acceleration',
    specs: 'Multilingual, High accuracy'
  },
  {
    name: 'CLIP-ViT-Large-Patch14',
    type: 'Vision-Language',
    performance: 'High',
    icon: Eye,
    price: '$0.02',
    description: 'Vision-language understanding with NVIDIA optimization',
    specs: 'Image-text matching, Zero-shot'
  },
  {
    name: 'Nemotron-4-340B-Instruct',
    type: 'Language Model',
    performance: 'Ultra High',
    icon: Brain,
    price: '$0.60',
    description: 'NVIDIA\'s most advanced language model for enterprise use',
    specs: '340B parameters, Enterprise-grade'
  },
  {
    name: 'ChatGLM3-6B',
    type: 'Language Model',
    performance: 'Medium',
    icon: MessageSquare,
    price: '$0.04',
    description: 'Bilingual conversational language model with NVIDIA acceleration',
    specs: '6B parameters, Chinese & English'
  },
  {
    name: 'Kosmos-2',
    type: 'Multimodal',
    performance: 'High',
    icon: Brain,
    price: '$0.10',
    description: 'Multimodal large language model with vision capabilities',
    specs: 'Text + Vision, Grounding'
  }
];

const getPerformanceColor = (performance: string) => {
  switch (performance) {
    case 'Ultra High': return 'from-red-500 to-pink-500';
    case 'High': return 'from-orange-500 to-yellow-500';
    case 'Medium': return 'from-blue-500 to-cyan-500';
    default: return 'from-gray-500 to-gray-600';
  }
};

const getTypeColor = (type: string) => {
  switch (type) {
    case 'Language Model': return 'from-purple-500 to-violet-500';
    case 'Code Generation': return 'from-green-500 to-emerald-500';
    case 'Image Generation': return 'from-pink-500 to-rose-500';
    case 'Speech Recognition': return 'from-blue-500 to-cyan-500';
    case 'Vision-Language': return 'from-teal-500 to-cyan-500';
    case 'Multimodal': return 'from-indigo-500 to-purple-500';
    default: return 'from-gray-500 to-gray-600';
  }
};

export default function NvidiaNim() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <nav className="text-sm text-gray-400 mb-4">
              <span>LLM Tools</span> <span className="mx-2">&gt;</span> 
              <span>Inferencing</span> <span className="mx-2">&gt;</span> 
              <span className="text-primary-400">NVIDIA NIM</span>
            </nav>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
              <Cpu className="inline-block mr-3 text-green-400" size={40} />
              NVIDIA NIM Inference Models
            </h1>
            <p className="text-lg text-gray-300 max-w-4xl">
              Deploy pre-optimized NVIDIA AI models with enterprise-grade performance and security. NVIDIA NIM provides production-ready inference with automatic scaling, optimization, and monitoring built-in.
            </p>
          </motion.div>

          {/* Search and Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 mb-8"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search NVIDIA NIM models..."
                className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-primary-500"
              />
            </div>
            <Button variant="secondary" className="flex items-center">
              <Filter size={16} className="mr-2" />
              Filter by Performance
            </Button>
          </motion.div>

          {/* Models Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {nvidiaModels.map((model, index) => (
              <motion.div
                key={model.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getTypeColor(model.type)} flex items-center justify-center`}>
                      <model.icon className="text-white" size={20} />
                    </div>
                    <div className={`text-xs bg-gradient-to-r ${getPerformanceColor(model.performance)} text-white px-2 py-1 rounded-full`}>
                      {model.performance}
                    </div>
                  </div>
                  
                  <h3 className="text-sm font-semibold text-white mb-1 leading-tight">{model.name}</h3>
                  <p className="text-xs text-primary-400 mb-2">{model.type}</p>
                  <p className="text-xs text-gray-400 mb-3 leading-relaxed">{model.description}</p>
                  <p className="text-xs text-gray-500 mb-4">{model.specs}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-green-400">{model.price}/request</span>
                    <Button size="sm">
                      Deploy
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Enterprise Features */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12"
          >
            <Card className="max-w-6xl mx-auto">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-4">
                  <Shield className="inline-block mr-2 text-green-400" size={24} />
                  Enterprise-Grade NVIDIA NIM Features
                </h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="text-white" size={24} />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">Optimized Performance</h4>
                  <p className="text-gray-400 text-sm">TensorRT optimization, multi-GPU scaling, and automatic batching for maximum throughput</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="text-white" size={24} />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">Enterprise Security</h4>
                  <p className="text-gray-400 text-sm">SOC 2 compliance, data encryption, and secure model serving with audit logs</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-violet-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Brain className="text-white" size={24} />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">Production Ready</h4>
                  <p className="text-gray-400 text-sm">Built-in monitoring, automatic scaling, and 99.9% uptime SLA</p>
                </div>
              </div>
              
              <div className="text-center">
                <Button size="lg" className="mr-4">
                  <Star className="mr-2" size={16} />
                  Start Free Trial
                </Button>
                <Button variant="secondary" size="lg">
                  Contact Enterprise Sales
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
