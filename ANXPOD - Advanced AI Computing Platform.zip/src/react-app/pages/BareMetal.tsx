import { Server, Cpu, HardDrive, Zap, IndianRupee, MemoryStick, Clock } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const bareMetalServers = [
  {
    name: 'AMD EPYC 9554',
    cpu: '64-Core 3.1GHz',
    memory: '512GB DDR5',
    storage: '2x 3.84TB NVMe SSD',
    network: '2x 25Gbps',
    price: '$210,240',
    period: 'Year',
    setup: '2-4 hours',
    availability: 'Available',
    popular: true,
    specs: {
      cores: '64 Cores / 128 Threads',
      baseFreq: '3.1GHz Base',
      boostFreq: '3.75GHz Boost',
      cache: '256MB L3 Cache'
    }
  },
  {
    name: 'Intel Xeon Platinum 8480+',
    cpu: '56-Core 2.0GHz',
    memory: '512GB DDR5',
    storage: '2x 3.84TB NVMe SSD',
    network: '2x 25Gbps',
    price: '$189,600',
    period: 'Year',
    setup: '2-4 hours',
    availability: 'Available',
    popular: false,
    specs: {
      cores: '56 Cores / 112 Threads',
      baseFreq: '2.0GHz Base',
      boostFreq: '3.8GHz Boost',
      cache: '105MB L3 Cache'
    }
  },
  {
    name: 'AMD EPYC 9454',
    cpu: '48-Core 2.75GHz',
    memory: '384GB DDR5',
    storage: '2x 1.92TB NVMe SSD',
    network: '2x 10Gbps',
    price: '$156,000',
    period: 'Year',
    setup: '2-4 hours',
    availability: 'Available',
    popular: true,
    specs: {
      cores: '48 Cores / 96 Threads',
      baseFreq: '2.75GHz Base',
      boostFreq: '3.65GHz Boost',
      cache: '256MB L3 Cache'
    }
  },
  {
    name: 'Intel Xeon Gold 6454S',
    cpu: '32-Core 2.2GHz',
    memory: '256GB DDR5',
    storage: '2x 1.92TB NVMe SSD',
    network: '2x 10Gbps',
    price: '$124,800',
    period: 'Year',
    setup: '2-4 hours',
    availability: 'Available',
    popular: false,
    specs: {
      cores: '32 Cores / 64 Threads',
      baseFreq: '2.2GHz Base',
      boostFreq: '3.4GHz Boost',
      cache: '60MB L3 Cache'
    }
  },
  {
    name: 'AMD EPYC 9354',
    cpu: '32-Core 3.25GHz',
    memory: '256GB DDR5',
    storage: '2x 960GB NVMe SSD',
    network: '2x 10Gbps',
    price: '$98,400',
    period: 'Year',
    setup: '2-4 hours',
    availability: 'Available',
    popular: false,
    specs: {
      cores: '32 Cores / 64 Threads',
      baseFreq: '3.25GHz Base',
      boostFreq: '3.8GHz Boost',
      cache: '256MB L3 Cache'
    }
  },
  {
    name: 'Intel Xeon Silver 4410Y',
    cpu: '12-Core 2.0GHz',
    memory: '128GB DDR5',
    storage: '2x 480GB NVMe SSD',
    network: '2x 1Gbps',
    price: '$62,400',
    period: 'Year',
    setup: '2-4 hours',
    availability: 'Available',
    popular: true,
    specs: {
      cores: '12 Cores / 24 Threads',
      baseFreq: '2.0GHz Base',
      boostFreq: '3.9GHz Boost',
      cache: '30MB L3 Cache'
    }
  }
];

export default function BareMetal() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <nav className="text-body-sm text-mutedText mb-4">
              <span>GPU Compute</span> <span className="mx-2">&gt;</span> <span className="text-neonRed">Bare Metal</span>
            </nav>
            <h1 className="text-heading-3xl text-primaryText mb-4">
              Bare Metal Servers
            </h1>
            <p className="text-body-lg text-mutedText max-w-3xl">
              Dedicated high-performance bare metal servers with latest AMD EPYC and Intel Xeon processors. Perfect for demanding workloads requiring maximum performance and full hardware control.
            </p>
          </div>

          {/* Server Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-system-lg">
            {bareMetalServers.map((server) => (
              <div key={server.name} className="relative">
                {server.popular && (
                  <div className="absolute -top-3 left-4 z-10">
                    <span className="bg-primary-gradient text-white text-body-xs font-semibold px-3 py-1 rounded-full">
                      Popular
                    </span>
                  </div>
                )}
                
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-neonRed to-laserRed flex items-center justify-center">
                      <Server className="text-white" size={24} />
                    </div>
                    <div className="text-body-xs bg-neonRed/20 text-neonRed px-2 py-1 rounded-full">
                      {server.availability}
                    </div>
                  </div>
                  
                  <h3 className="text-heading-xl text-primaryText mb-1">{server.name}</h3>
                  <p className="text-neonRed text-body-sm mb-4">{server.cpu}</p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between text-body-sm">
                      <div className="flex items-center text-mutedText">
                        <MemoryStick size={14} className="mr-1" />
                        <span>Memory</span>
                      </div>
                      <span className="text-primaryText">{server.memory}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-body-sm">
                      <div className="flex items-center text-mutedText">
                        <HardDrive size={14} className="mr-1" />
                        <span>Storage</span>
                      </div>
                      <span className="text-primaryText">{server.storage}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-body-sm">
                      <div className="flex items-center text-mutedText">
                        <Zap size={14} className="mr-1" />
                        <span>Network</span>
                      </div>
                      <span className="text-primaryText">{server.network}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-body-sm">
                      <div className="flex items-center text-mutedText">
                        <Clock size={14} className="mr-1" />
                        <span>Setup</span>
                      </div>
                      <span className="text-primaryText">{server.setup}</span>
                    </div>
                  </div>

                  {/* Detailed Specs */}
                  <div className="border-t border-gridDivider pt-4 mb-4">
                    <p className="text-body-xs text-mutedText mb-1">CPU: {server.specs.cores}</p>
                    <p className="text-body-xs text-mutedText mb-1">Frequency: {server.specs.baseFreq} / {server.specs.boostFreq}</p>
                    <p className="text-body-xs text-mutedText">Cache: {server.specs.cache}</p>
                  </div>
                  
                  {/* Pricing */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center text-body-sm">
                      <IndianRupee size={14} className="mr-1 text-mutedText" />
                      <span className="text-mutedText">Price/{server.period.toLowerCase()}</span>
                    </div>
                    <span className="text-neonRed font-semibold text-heading-lg">{server.price}</span>
                  </div>
                  
                  <Button className="w-full">
                    Reserve Server
                  </Button>
                </Card>
              </div>
            ))}
          </div>

          {/* Info Section */}
          <div className="mt-12">
            <Card className="max-w-4xl mx-auto text-center">
              <h3 className="text-heading-xl text-primaryText mb-4">Need Custom Configuration?</h3>
              <p className="text-mutedText mb-6">
                Contact our team for custom bare metal configurations with specific CPU, memory, storage, and network requirements. We offer enterprise-grade support and SLAs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="secondary">
                  Custom Configuration
                </Button>
                <Button>
                  Contact Sales
                </Button>
              </div>
            </Card>
          </div>

          {/* Features Section */}
          <div className="mt-12">
            <h2 className="text-heading-xl text-primaryText mb-6 text-center">Why Choose Bare Metal?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-system-lg">
              <Card className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-neonRed to-laserRed flex items-center justify-center mx-auto mb-4">
                  <Cpu className="text-white" size={24} />
                </div>
                <h3 className="text-heading-lg text-primaryText mb-2">Maximum Performance</h3>
                <p className="text-mutedText text-body-sm leading-relaxed">
                  No virtualization overhead. Direct access to hardware for peak performance and lowest latency.
                </p>
              </Card>

              <Card className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-hotEmber to-crimson flex items-center justify-center mx-auto mb-4">
                  <Server className="text-white" size={24} />
                </div>
                <h3 className="text-heading-lg text-primaryText mb-2">Complete Control</h3>
                <p className="text-mutedText text-body-sm leading-relaxed">
                  Full root access, custom OS installations, and complete hardware control for your applications.
                </p>
              </Card>

              <Card className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-deepRuby to-bloodline flex items-center justify-center mx-auto mb-4">
                  <Zap className="text-white" size={24} />
                </div>
                <h3 className="text-heading-lg text-primaryText mb-2">Enterprise Ready</h3>
                <p className="text-mutedText text-body-sm leading-relaxed">
                  24/7 support, SLA guarantees, and enterprise-grade infrastructure for mission-critical workloads.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
