import { Settings, Cpu, Brain, Zap, Monitor, Activity, Sliders, Power, Pause, Play, RotateCcw, Plus } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const activeInstances = [
  {
    id: 'gpu-h100-001',
    name: 'NVIDIA H100 - Training',
    model: 'Llama 3.1 8B Fine-tuning',
    status: 'running',
    uptime: '4h 32m',
    usage: 85,
    cost: '₹8,500/hr',
    location: 'Mumbai, India'
  },
  {
    id: 'gpu-a100-002',
    name: 'NVIDIA A100 - Inference',
    model: 'Stable Diffusion XL',
    status: 'running',
    uptime: '12h 18m',
    usage: 62,
    cost: '₹6,200/hr',
    location: 'Bangalore, India'
  },
  {
    id: 'gpu-t4-003',
    name: 'NVIDIA T4 - Development',
    model: 'ComfyUI',
    status: 'paused',
    uptime: '2h 45m',
    usage: 0,
    cost: '₹1,200/hr',
    location: 'Delhi, India'
  }
];

const systemMetrics = [
  {
    title: 'GPU Utilization',
    value: '73%',
    trend: '+5%',
    color: 'from-neonRed to-laserRed',
    icon: Cpu
  },
  {
    title: 'Memory Usage',
    value: '68%',
    trend: '+2%',
    color: 'from-hotEmber to-crimson',
    icon: Brain
  },
  {
    title: 'Power Consumption',
    value: '420W',
    trend: '-8W',
    color: 'from-deepRuby to-bloodline',
    icon: Zap
  },
  {
    title: 'Temperature',
    value: '74°C',
    trend: '+2°C',
    color: 'from-crimson to-neonRed',
    icon: Monitor
  }
];

const automationRules = [
  {
    name: 'Auto-Scale Training',
    description: 'Automatically scale GPU instances based on queue length',
    enabled: true,
    trigger: 'Queue > 5 jobs'
  },
  {
    name: 'Cost Optimization',
    description: 'Pause idle instances after 30 minutes of inactivity',
    enabled: true,
    trigger: 'Idle > 30min'
  },
  {
    name: 'Resource Alerts',
    description: 'Send notifications when GPU usage exceeds 90%',
    enabled: false,
    trigger: 'Usage > 90%'
  },
  {
    name: 'Scheduled Shutdown',
    description: 'Automatically shutdown non-critical instances at night',
    enabled: true,
    trigger: '11:00 PM IST'
  }
];

export default function AIController() {
  return (
    <Layout>
      <div className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-heading-3xl text-primaryText mb-4">
              <Settings className="inline-block mr-3 text-neonRed" size={40} />
              AI Controller
            </h1>
            <p className="text-body-lg text-mutedText">
              Monitor and control your AI infrastructure with intelligent automation and real-time insights
            </p>
          </div>

          {/* System Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-lg mb-8">
            {systemMetrics.map((metric) => (
              <div key={metric.title}>
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${metric.color} flex items-center justify-center`}>
                      <metric.icon className="text-white" size={24} />
                    </div>
                    <div className="text-xs bg-neonRed/20 text-neonRed px-2 py-1 rounded-full">
                      {metric.trend}
                    </div>
                  </div>
                  
                  <h3 className="text-heading-2xl text-primaryText mb-1">{metric.value}</h3>
                  <p className="text-mutedText text-body-sm">{metric.title}</p>
                </Card>
              </div>
            ))}
          </div>

          {/* Active Instances */}
          <div className="mb-8">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-heading-xl text-primaryText">Active GPU Instances</h3>
                <Button variant="secondary" size="sm">
                  <Plus className="mr-2" size={16} />
                  Add Instance
                </Button>
              </div>
              
              <div className="space-y-4">
                {activeInstances.map((instance) => (
                  <div key={instance.id} className="p-4 bg-charcoalSurface rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${
                          instance.status === 'running' ? 'bg-neonRed' :
                          instance.status === 'paused' ? 'bg-hotEmber' :
                          'bg-crimson'
                        }`}></div>
                        <div>
                          <h4 className="text-primaryText font-medium">{instance.name}</h4>
                          <p className="text-mutedText text-body-sm">{instance.model}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          {instance.status === 'running' ? <Pause size={16} /> : <Play size={16} />}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <RotateCcw size={16} />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Power size={16} />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                      <div>
                        <p className="text-mutedText">Uptime</p>
                        <p className="text-primaryText">{instance.uptime}</p>
                      </div>
                      <div>
                        <p className="text-mutedText">Usage</p>
                        <p className="text-primaryText">{instance.usage}%</p>
                      </div>
                      <div>
                        <p className="text-mutedText">Cost</p>
                        <p className="text-neonRed">{instance.cost}</p>
                      </div>
                      <div>
                        <p className="text-mutedText">Location</p>
                        <p className="text-primaryText">{instance.location}</p>
                      </div>
                      <div>
                        <p className="text-mutedText">Status</p>
                        <p className={`capitalize ${
                          instance.status === 'running' ? 'text-neonRed' :
                          instance.status === 'paused' ? 'text-hotEmber' :
                          'text-crimson'
                        }`}>{instance.status}</p>
                      </div>
                    </div>
                    
                    {instance.usage > 0 && (
                      <div className="mt-3">
                        <div className="flex justify-between text-xs text-mutedText mb-1">
                          <span>GPU Usage</span>
                          <span>{instance.usage}%</span>
                        </div>
                        <div className="w-full bg-gridDivider rounded-full h-2">
                          <div 
                            className="bg-primary-gradient h-2 rounded-full"
                            style={{ width: `${instance.usage}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Automation Rules */}
          <div className="mb-8">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-heading-xl text-primaryText">Automation Rules</h3>
                <Button variant="secondary" size="sm">
                  <Sliders className="mr-2" size={16} />
                  Configure
                </Button>
              </div>
              
              <div className="space-y-4">
                {automationRules.map((rule) => (
                  <div key={rule.name} className="flex items-center justify-between p-4 bg-charcoalSurface rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className={`w-4 h-4 rounded-full ${
                        rule.enabled ? 'bg-neonRed' : 'bg-gridDivider'
                      }`}></div>
                      <div>
                        <h4 className="text-primaryText font-medium">{rule.name}</h4>
                        <p className="text-mutedText text-body-sm">{rule.description}</p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-mutedText text-body-sm">{rule.trigger}</p>
                      <button className={`text-xs px-2 py-1 rounded-full ${
                        rule.enabled 
                          ? 'bg-neonRed/20 text-neonRed' 
                          : 'bg-gridDivider/20 text-mutedText'
                      }`}>
                        {rule.enabled ? 'Enabled' : 'Disabled'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Quick Actions */}
          <div>
            <Card className="p-6">
              <h3 className="text-heading-xl text-primaryText mb-6">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-md">
                <Button className="flex items-center justify-center py-4">
                  <Activity className="mr-2" size={20} />
                  System Health Check
                </Button>
                <Button variant="secondary" className="flex items-center justify-center py-4">
                  <Sliders className="mr-2" size={20} />
                  Performance Tuning
                </Button>
                <Button variant="secondary" className="flex items-center justify-center py-4">
                  <Power className="mr-2" size={20} />
                  Bulk Actions
                </Button>
                <Button variant="secondary" className="flex items-center justify-center py-4">
                  <Monitor className="mr-2" size={20} />
                  Resource Planning
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
