import { Cpu, HardDrive, Zap, IndianRupee, MemoryStick } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const gpuInstances = [
  {
    name: 'NVIDIA B200',
    memory: '180GB HBM3e',
    price: '₹12,500',
    ram: '512GB DDR5',
    vcpu: '128 vCPUs',
    storage: '2TB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA B200',
    cuda: 'CUDA 12.4',
    performance: 'Ultra High',
    popular: false
  },
  {
    name: 'NVIDIA H200',
    memory: '141GB HBM3e',
    price: '₹10,800',
    ram: '256GB DDR5',
    vcpu: '64 vCPUs',
    storage: '1TB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA H200',
    cuda: 'CUDA 12.3',
    performance: 'Ultra High',
    popular: false
  },
  {
    name: 'NVIDIA H100',
    memory: '80GB HBM3',
    price: '₹8,500',
    ram: '256GB DDR5',
    vcpu: '64 vCPUs',
    storage: '1TB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA H100 SXM',
    cuda: 'CUDA 12.2',
    performance: 'Ultra High',
    popular: true
  },
  {
    name: 'NVIDIA A100',
    memory: '80GB HBM2e',
    price: '₹6,200',
    ram: '128GB DDR4',
    vcpu: '32 vCPUs',
    storage: '500GB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA A100 SXM',
    cuda: 'CUDA 12.1',
    performance: 'High',
    popular: true
  },
  {
    name: 'NVIDIA A100',
    memory: '40GB HBM2e',
    price: '₹4,800',
    ram: '128GB DDR4',
    vcpu: '32 vCPUs',
    storage: '500GB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA A100 PCIe',
    cuda: 'CUDA 12.1',
    performance: 'High',
    popular: false
  },
  {
    name: 'NVIDIA L40S',
    memory: '48GB GDDR6',
    price: '₹4,200',
    ram: '128GB DDR4',
    vcpu: '32 vCPUs',
    storage: '500GB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA L40S PCIe',
    cuda: 'CUDA 12.1',
    performance: 'High',
    popular: false
  },
  {
    name: 'NVIDIA A10G',
    memory: '24GB GDDR6',
    price: '₹2,400',
    ram: '64GB DDR4',
    vcpu: '16 vCPUs',
    storage: '250GB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA A10G PCIe',
    cuda: 'CUDA 12.0',
    performance: 'Medium',
    popular: false
  },
  {
    name: 'NVIDIA T4',
    memory: '16GB GDDR6',
    price: '₹1,200',
    ram: '32GB DDR4',
    vcpu: '8 vCPUs',
    storage: '250GB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA T4 PCIe',
    cuda: 'CUDA 11.8',
    performance: 'Medium',
    popular: true
  },
  {
    name: 'NVIDIA L4',
    memory: '24GB GDDR6',
    price: '₹1,800',
    ram: '64GB DDR4',
    vcpu: '16 vCPUs',
    storage: '250GB NVMe SSD',
    os: 'Ubuntu 22.04',
    gpus: '1x NVIDIA L4 PCIe',
    cuda: 'CUDA 12.0',
    performance: 'Medium',
    popular: false
  }
];

const getPerformanceColor = (performance: string) => {
  switch (performance) {
    case 'Ultra High': return 'from-neonRed to-laserRed';
    case 'High': return 'from-hotEmber to-crimson';
    case 'Medium': return 'from-deepRuby to-bloodline';
    default: return 'from-gridDivider to-mutedText';
  }
};

export default function GPUInstances() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <nav className="text-sm text-mutedText mb-4">
              <span>GPU Compute</span> <span className="mx-2">&gt;</span> <span className="text-neonRed">GPU Instances</span>
            </nav>
            <h1 className="text-heading-3xl text-primaryText mb-4">
              GPU Instances
            </h1>
            <p className="text-body-lg text-mutedText max-w-3xl">
              Quick Deploy GPU instance from standard configuration Templates
            </p>
          </div>

          {/* GPU Instances Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-system-lg">
            {gpuInstances.map((instance) => (
              <div key={`${instance.name}-${instance.memory}`} className="relative">
                {instance.popular && (
                  <div className="absolute -top-3 left-4 z-10">
                    <span className="bg-primary-gradient text-white text-xs font-semibold px-3 py-1 rounded-full">
                      Popular
                    </span>
                  </div>
                )}
                
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-neonRed to-laserRed flex items-center justify-center">
                      <Cpu className="text-white" size={24} />
                    </div>
                    <div className={`text-xs bg-gradient-to-r ${getPerformanceColor(instance.performance)} text-white px-2 py-1 rounded-full`}>
                      {instance.performance}
                    </div>
                  </div>
                  
                  <h3 className="text-heading-xl text-primaryText mb-1">{instance.name}</h3>
                  <p className="text-neonRed text-body-sm mb-4">{instance.memory}</p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-mutedText">
                        <IndianRupee size={14} className="mr-1" />
                        <span>Price/hr</span>
                      </div>
                      <span className="text-primaryText font-semibold">{instance.price}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-mutedText">
                        <MemoryStick size={14} className="mr-1" />
                        <span>RAM</span>
                      </div>
                      <span className="text-primaryText">{instance.ram}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-mutedText">
                        <Cpu size={14} className="mr-1" />
                        <span>vCPU</span>
                      </div>
                      <span className="text-primaryText">{instance.vcpu}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-mutedText">
                        <HardDrive size={14} className="mr-1" />
                        <span>Storage</span>
                      </div>
                      <span className="text-primaryText">{instance.storage}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-mutedText">
                        <Zap size={14} className="mr-1" />
                        <span>CUDA</span>
                      </div>
                      <span className="text-primaryText">{instance.cuda}</span>
                    </div>
                  </div>
                  
                  <div className="border-t border-gridDivider pt-4 mb-4">
                    <p className="text-xs text-mutedText mb-1">OS: {instance.os}</p>
                    <p className="text-xs text-mutedText">GPU: {instance.gpus}</p>
                  </div>
                  
                  <Button className="w-full">
                    Deploy Instance
                  </Button>
                </Card>
              </div>
            ))}
          </div>

          {/* Info Section */}
          <div className="mt-12">
            <Card className="max-w-4xl mx-auto text-center">
              <h3 className="text-heading-xl text-primaryText mb-4">Need Multiple GPUs?</h3>
              <p className="text-mutedText mb-6">
                Scale your workloads with multi-GPU configurations. Contact our team for custom multi-GPU setups and enterprise solutions.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="secondary">
                  Multi-GPU Configuration
                </Button>
                <Button>
                  Contact Sales
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
