import { motion } from 'framer-motion';
import { Search, Filter, Star, Zap, Code, Image, MessageSquare, Eye, Brain, Download, Heart } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const huggingFaceModels = [
  {
    name: 'Meta-Llama-3.1-8B-Instruct',
    type: 'Text Generation',
    downloads: '2.1M',
    likes: '1.2k',
    icon: MessageSquare,
    price: '$0.03',
    description: 'Advanced instruction-following language model by Meta',
    author: 'meta-llama'
  },
  {
    name: 'microsoft/DialoGPT-medium',
    type: 'Conversational',
    downloads: '890k',
    likes: '3.4k',
    icon: MessageSquare,
    price: '$0.02',
    description: 'Conversational response generation model',
    author: 'microsoft'
  },
  {
    name: 'stabilityai/stable-diffusion-xl-base-1.0',
    type: 'Image Generation',
    downloads: '5.2M',
    likes: '8.1k',
    icon: Image,
    price: '$0.05',
    description: 'High-resolution text-to-image generation',
    author: 'stabilityai'
  },
  {
    name: 'openai/whisper-large-v3',
    type: 'Speech Recognition',
    downloads: '1.8M',
    likes: '2.7k',
    icon: MessageSquare,
    price: '$0.02',
    description: 'Multilingual speech recognition model',
    author: 'openai'
  },
  {
    name: 'sentence-transformers/all-MiniLM-L6-v2',
    type: 'Sentence Similarity',
    downloads: '12.3M',
    likes: '4.6k',
    icon: Brain,
    price: '$0.01',
    description: 'Sentence embeddings for semantic similarity',
    author: 'sentence-transformers'
  },
  {
    name: 'microsoft/CodeBERT-base',
    type: 'Code Understanding',
    downloads: '780k',
    likes: '1.9k',
    icon: Code,
    price: '$0.02',
    description: 'Pre-trained model for programming languages',
    author: 'microsoft'
  },
  {
    name: 'google/flan-t5-large',
    type: 'Text Generation',
    downloads: '3.4M',
    likes: '2.1k',
    icon: MessageSquare,
    price: '$0.03',
    description: 'Instruction-tuned text-to-text transfer transformer',
    author: 'google'
  },
  {
    name: 'facebook/bart-large-cnn',
    type: 'Summarization',
    downloads: '1.6M',
    likes: '3.8k',
    icon: MessageSquare,
    price: '$0.02',
    description: 'Text summarization model',
    author: 'facebook'
  },
  {
    name: 'microsoft/DiT-XL-2-256',
    type: 'Image Generation',
    downloads: '420k',
    likes: '890',
    icon: Image,
    price: '$0.04',
    description: 'Diffusion Transformer for image generation',
    author: 'microsoft'
  },
  {
    name: 'runwayml/stable-diffusion-v1-5',
    type: 'Image Generation',
    downloads: '8.9M',
    likes: '12.4k',
    icon: Image,
    price: '$0.05',
    description: 'Popular stable diffusion model for image generation',
    author: 'runwayml'
  },
  {
    name: 'microsoft/speecht5_tts',
    type: 'Text-to-Speech',
    downloads: '650k',
    likes: '1.4k',
    icon: MessageSquare,
    price: '$0.02',
    description: 'High-quality text-to-speech synthesis',
    author: 'microsoft'
  },
  {
    name: 'google/vit-base-patch16-224',
    type: 'Image Classification',
    downloads: '2.1M',
    likes: '5.2k',
    icon: Eye,
    price: '$0.01',
    description: 'Vision Transformer for image classification',
    author: 'google'
  }
];

const getTypeColor = (type: string) => {
  switch (type) {
    case 'Text Generation': return 'from-orange-500 to-yellow-500';
    case 'Conversational': return 'from-blue-500 to-cyan-500';
    case 'Image Generation': return 'from-purple-500 to-pink-500';
    case 'Speech Recognition': return 'from-green-500 to-emerald-500';
    case 'Sentence Similarity': return 'from-indigo-500 to-blue-500';
    case 'Code Understanding': return 'from-teal-500 to-cyan-500';
    case 'Summarization': return 'from-red-500 to-rose-500';
    case 'Text-to-Speech': return 'from-violet-500 to-purple-500';
    case 'Image Classification': return 'from-amber-500 to-orange-500';
    default: return 'from-gray-500 to-gray-600';
  }
};

export default function HuggingFace() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <nav className="text-sm text-gray-400 mb-4">
              <span>LLM Tools</span> <span className="mx-2">&gt;</span> 
              <span>Inferencing</span> <span className="mx-2">&gt;</span> 
              <span className="text-primary-400">Hugging Face</span>
            </nav>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
              🤗 Hugging Face Models
            </h1>
            <p className="text-lg text-gray-300 max-w-4xl">
              Deploy any Hugging Face model with a single click! Access the world's largest collection of pre-trained AI models, from language models to computer vision, all optimized for high-performance inference on our GPU infrastructure.
            </p>
          </motion.div>

          {/* Search and Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 mb-8"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search Hugging Face models..."
                className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-primary-500"
              />
            </div>
            <Button variant="secondary" className="flex items-center">
              <Filter size={16} className="mr-2" />
              Filter by Type
            </Button>
          </motion.div>

          {/* Models Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {huggingFaceModels.map((model, index) => (
              <motion.div
                key={model.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getTypeColor(model.type)} flex items-center justify-center`}>
                      <model.icon className="text-white" size={20} />
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-gray-400">
                      <Download size={12} />
                      <span>{model.downloads}</span>
                      <Heart size={12} />
                      <span>{model.likes}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-sm font-semibold text-white mb-1 leading-tight">{model.name}</h3>
                  <p className="text-xs text-primary-400 mb-1">by {model.author}</p>
                  <p className="text-xs text-gray-500 mb-2">{model.type}</p>
                  <p className="text-xs text-gray-400 mb-4 leading-relaxed">{model.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-green-400">{model.price}/request</span>
                    <Button size="sm">
                      Deploy
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12"
          >
            <Card className="max-w-4xl mx-auto">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-4">
                  <Zap className="inline-block mr-2 text-yellow-400" size={24} />
                  One-Click Deployment from Hugging Face Hub
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-400 mb-2">180k+</div>
                    <div className="text-sm text-gray-300">Available Models</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-400 mb-2">30+</div>
                    <div className="text-sm text-gray-300">Model Categories</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400 mb-2">Auto</div>
                    <div className="text-sm text-gray-300">GPU Optimization</div>
                  </div>
                </div>
                <p className="text-gray-400 mb-6">
                  Access the entire Hugging Face model hub with automatic GPU optimization and scaling. No setup required - just click and deploy!
                </p>
                <Button size="lg">
                  <Star className="mr-2" size={16} />
                  Browse All 180k+ Models
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
