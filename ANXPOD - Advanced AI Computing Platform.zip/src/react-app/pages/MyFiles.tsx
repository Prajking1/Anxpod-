import { FolderOpen, Upload, File, Image, FileText, Download, Trash2, Search, Filter, Plus } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const files = [
  {
    name: 'training_dataset.csv',
    type: 'csv',
    size: '145.2 MB',
    modified: '2 hours ago',
    icon: FileText,
    color: 'from-neonRed to-laserRed'
  },
  {
    name: 'model_weights.pytorch',
    type: 'model',
    size: '2.8 GB',
    modified: '1 day ago',
    icon: File,
    color: 'from-hotEmber to-crimson'
  },
  {
    name: 'validation_images',
    type: 'folder',
    size: '894 MB',
    modified: '3 days ago',
    icon: FolderOpen,
    color: 'from-deepRuby to-bloodline'
  },
  {
    name: 'fine_tuned_llama.safetensors',
    type: 'model',
    size: '4.2 GB',
    modified: '1 week ago',
    icon: File,
    color: 'from-crimson to-neonRed'
  },
  {
    name: 'dataset_preprocessing.py',
    type: 'python',
    size: '12.5 KB',
    modified: '2 weeks ago',
    icon: FileText,
    color: 'from-laserRed to-hotEmber'
  },
  {
    name: 'evaluation_results.json',
    type: 'json',
    size: '8.9 KB',
    modified: '2 weeks ago',
    icon: FileText,
    color: 'from-bloodline to-deepRuby'
  },
  {
    name: 'training_logs',
    type: 'folder',
    size: '156 MB',
    modified: '3 weeks ago',
    icon: FolderOpen,
    color: 'from-neonRed to-crimson'
  },
  {
    name: 'generated_images',
    type: 'folder',
    size: '1.2 GB',
    modified: '1 month ago',
    icon: Image,
    color: 'from-hotEmber to-laserRed'
  }
];

const storageStats = [
  {
    title: 'Total Storage Used',
    value: '9.8 GB',
    limit: '50 GB',
    percentage: 19.6,
    color: 'from-neonRed to-laserRed'
  },
  {
    title: 'Files Uploaded',
    value: '147',
    change: '+12 this week',
    color: 'from-hotEmber to-crimson'
  },
  {
    title: 'Models Stored',
    value: '8',
    change: '+2 this month',
    color: 'from-deepRuby to-bloodline'
  }
];

export default function MyFiles() {
  return (
    <Layout>
      <div className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-heading-3xl text-primaryText mb-4">
              <FolderOpen className="inline-block mr-3 text-neonRed" size={40} />
              My Files
            </h1>
            <p className="text-body-lg text-mutedText">
              Manage your datasets, models, and training files in one secure location
            </p>
          </div>

          {/* Storage Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-system-lg mb-8">
            {storageStats.map((stat) => (
              <div key={stat.title}>
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-heading-lg text-primaryText">{stat.title}</h3>
                  </div>
                  
                  <div className="text-heading-2xl text-primaryText mb-2">{stat.value}</div>
                  
                  {stat.limit && (
                    <div className="mb-2">
                      <div className="flex justify-between text-sm text-mutedText mb-1">
                        <span>Used</span>
                        <span>{stat.limit}</span>
                      </div>
                      <div className="w-full bg-gridDivider rounded-full h-2">
                        <div 
                          className={`bg-gradient-to-r ${stat.color} h-2 rounded-full`}
                          style={{ width: `${stat.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                  
                  {stat.change && (
                    <p className="text-mutedText text-body-sm">{stat.change}</p>
                  )}
                </Card>
              </div>
            ))}
          </div>

          {/* File Actions */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-mutedText" size={20} />
              <input
                type="text"
                placeholder="Search files..."
                className="w-full pl-10 pr-4 py-3 bg-charcoalSurface border border-gridDivider rounded-lg text-primaryText placeholder-mutedText focus:outline-none focus:border-neonRed"
              />
            </div>
            <Button variant="secondary" className="flex items-center">
              <Filter size={16} className="mr-2" />
              Filter
            </Button>
            <Button className="flex items-center">
              <Upload size={16} className="mr-2" />
              Upload Files
            </Button>
            <Button variant="secondary" className="flex items-center">
              <Plus size={16} className="mr-2" />
              New Folder
            </Button>
          </div>

          {/* Files Grid */}
          <div>
            <Card className="p-6">
              <div className="grid grid-cols-1 gap-4">
                {files.map((file) => (
                  <div key={file.name} className="flex items-center justify-between p-4 bg-charcoalSurface rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${file.color} flex items-center justify-center`}>
                        <file.icon className="text-white" size={20} />
                      </div>
                      <div>
                        <p className="text-primaryText font-medium">{file.name}</p>
                        <p className="text-mutedText text-body-sm">{file.size} • Modified {file.modified}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">
                        <Download size={16} />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Upload Area */}
          <div className="mt-8">
            <Card className="p-8 text-center border-2 border-dashed border-gridDivider">
              <div className="w-16 h-16 bg-primary-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="text-white" size={24} />
              </div>
              <h3 className="text-heading-xl text-primaryText mb-2">Drag & Drop Files Here</h3>
              <p className="text-mutedText mb-6">
                Upload datasets, models, or any files needed for your AI projects. Supports all common formats.
              </p>
              <div className="flex justify-center space-x-4">
                <Button>
                  <Upload className="mr-2" size={16} />
                  Browse Files
                </Button>
                <Button variant="secondary">
                  <FolderOpen className="mr-2" size={16} />
                  Upload Folder
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
