import { Code, Terminal, Brain, Database, Monitor, Play } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const templates = [
  {
    name: 'ComfyUI',
    description: 'ComfyUI is a node-based interface and inference engine for generative AI. Users can combine various AI models and operations through nodes to achieve highly customizable and controllable content generation',
    icon: Brain,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'Image Generation'
  },
  {
    name: 'N8n',
    description: 'n8n is a workflow automation platform that gives technical teams the flexibility of code with the speed of no-code. With 400+ integrations, native AI capabilities, and a fair-code license, n8n lets you build powerful automations while maintaining full control over your data and deployments.',
    icon: Terminal,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'Automation'
  },
  {
    name: 'Langflow',
    description: 'Langflow is a powerful and intuitive platform designed for building, iterating, and deploying AI applications. Leveraging a visual interface, users can effortlessly create flows by dragging and connecting components, making AI app development accessible and efficient.',
    icon: Code,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'LLM Tools'
  },
  {
    name: 'TensorFlow 2.17.1',
    description: 'TensorFlow is an open source platform for machine learning. It provides comprehensive tools and libraries in a flexible architecture allowing easy deployment across a variety of platforms and devices.',
    icon: Database,
    os: 'Ubuntu 24.04',
    python: 'Python 3.12.3',
    category: 'ML Framework'
  },
  {
    name: 'PyTorch 2.4.0',
    description: 'PyTorch is a GPU accelerated tensor computational framework. Functionality can be extended with common Python libraries such as NumPy and SciPy. Automatic differentiation is done with a tape-based system at the functional and neural network layer levels.',
    icon: Database,
    os: 'Ubuntu 24.04',
    python: 'Python 3.12.3',
    category: 'ML Framework'
  },
  {
    name: 'Ubuntu 24.04',
    description: 'Ubuntu is a Debian-based Linux operating system that runs from the desktop to the cloud, to all your internet connected things. It is the world\'s most popular open-source OS.',
    icon: Monitor,
    os: 'Ubuntu 24.04',
    python: 'Python 3.12.3',
    category: 'Operating System'
  },
  {
    name: 'VSCode',
    description: 'Visual Studio Code is a lightweight but powerful source code editor with built-in support for JavaScript, TypeScript, Node.js, and a rich ecosystem of extensions for other languages and runtimes.',
    icon: Code,
    os: 'Ubuntu 24.04',
    python: 'Python 3.12.3',
    category: 'Development'
  },
  {
    name: 'PyTorch 2.4.0',
    description: 'PyTorch is a GPU accelerated tensor computational framework. Functionality can be extended with common Python libraries such as NumPy and SciPy. Automatic differentiation is done with a tape-based system at the functional and neural network layer levels.',
    icon: Database,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'ML Framework'
  },
  {
    name: 'TensorFlow 2.17.1',
    description: 'TensorFlow is an open source platform for machine learning. It provides comprehensive tools and libraries in a flexible architecture allowing easy deployment across a variety of platforms and devices.',
    icon: Database,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'ML Framework'
  },
  {
    name: 'TensorFlow 2.17.1',
    description: 'TensorFlow is an open source platform for machine learning. It provides comprehensive tools and libraries in a flexible architecture allowing easy deployment across a variety of platforms and devices.',
    icon: Database,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'ML Framework'
  },
  {
    name: 'Ubuntu 22.04',
    description: 'Ubuntu is a Debian-based Linux operating system that runs from the desktop to the cloud, to all your internet connected things. It is the world\'s most popular open-source OS.',
    icon: Monitor,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'Operating System'
  },
  {
    name: 'VSCode',
    description: 'Visual Studio Code is a lightweight but powerful source code editor with built-in support for JavaScript, TypeScript, Node.js, and a rich ecosystem of extensions for other languages and runtimes.',
    icon: Code,
    os: 'Ubuntu 22.04',
    python: 'Python 3.10.12',
    category: 'Development'
  }
];

export default function GPUTemplates() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <nav className="text-sm text-mutedText mb-4">
              <span>GPU Compute</span> <span className="mx-2">&gt;</span> <span className="text-neonRed">AI/ML Templates</span>
            </nav>
            <h1 className="text-heading-3xl text-primaryText mb-4">
              AI/ML Templates
            </h1>
            <p className="text-body-lg text-mutedText max-w-3xl">
              Below are standard AI/ML packages available for quick deployment on high performance GPUs.
            </p>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-system-lg">
            {templates.map((template) => (
              <div key={template.name}>
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-primary-gradient flex items-center justify-center">
                      <template.icon className="text-white" size={24} />
                    </div>
                    <span className="text-xs bg-neonRed/20 text-neonRed px-2 py-1 rounded-full">
                      {template.category}
                    </span>
                  </div>
                  
                  <h3 className="text-heading-xl text-primaryText mb-2">{template.name}</h3>
                  <p className="text-mutedText text-body-sm mb-4 leading-relaxed">{template.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-mutedText">OS:</span>
                      <span className="text-primaryText">{template.os}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-mutedText">Runtime:</span>
                      <span className="text-primaryText">{template.python}</span>
                    </div>
                  </div>
                  
                  <Button className="w-full group">
                    <Play size={16} className="mr-2" />
                    Deploy
                  </Button>
                </Card>
              </div>
            ))}
          </div>

          {/* Additional Info */}
          <div className="mt-12 text-center">
            <Card className="max-w-2xl mx-auto">
              <h3 className="text-heading-xl text-primaryText mb-4">Need a Custom Template?</h3>
              <p className="text-mutedText mb-6">
                Don't see what you need? We can create custom templates tailored to your specific requirements.
              </p>
              <Button variant="secondary">
                Request Custom Template
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
