import { FileText, Search, Book, Code, Zap, Settings, Database, Brain, ExternalLink, Clock } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const docCategories = [
  {
    title: 'Getting Started',
    description: 'Quick start guides and basic concepts',
    icon: Zap,
    color: 'from-neonRed to-laserRed',
    articles: 12
  },
  {
    title: 'GPU Computing',
    description: 'GPU instances, templates, and deployment',
    icon: Settings,
    color: 'from-hotEmber to-crimson',
    articles: 18
  },
  {
    title: 'LLM Tools',
    description: 'Language models, fine-tuning, and RAG',
    icon: Brain,
    color: 'from-deepRuby to-bloodline',
    articles: 24
  },
  {
    title: 'API Reference',
    description: 'Complete API documentation and examples',
    icon: Code,
    color: 'from-crimson to-neonRed',
    articles: 35
  },
  {
    title: 'Database',
    description: 'Data management and storage solutions',
    icon: Database,
    color: 'from-laserRed to-hotEmber',
    articles: 8
  },
  {
    title: 'Tutorials',
    description: 'Step-by-step guides and examples',
    icon: Book,
    color: 'from-bloodline to-deepRuby',
    articles: 15
  }
];

const popularArticles = [
  {
    title: 'How to Deploy Your First GPU Instance',
    category: 'Getting Started',
    readTime: '5 min read',
    lastUpdated: '2 days ago',
    views: '2.1k views'
  },
  {
    title: 'Fine-tuning Llama 3.1 Models',
    category: 'LLM Tools',
    readTime: '12 min read',
    lastUpdated: '1 week ago',
    views: '1.8k views'
  },
  {
    title: 'Building RAG Applications with Your Data',
    category: 'LLM Tools',
    readTime: '15 min read',
    lastUpdated: '3 days ago',
    views: '1.5k views'
  },
  {
    title: 'GPU Instance Types and Pricing',
    category: 'GPU Computing',
    readTime: '8 min read',
    lastUpdated: '1 day ago',
    views: '3.2k views'
  },
  {
    title: 'API Authentication and Rate Limits',
    category: 'API Reference',
    readTime: '6 min read',
    lastUpdated: '5 days ago',
    views: '1.2k views'
  },
  {
    title: 'ComfyUI Setup and Configuration',
    category: 'Tutorials',
    readTime: '20 min read',
    lastUpdated: '1 week ago',
    views: '2.8k views'
  }
];

const quickLinks = [
  {
    title: 'System Status',
    description: 'Check current system status and uptime',
    icon: ExternalLink,
    url: 'https://status.qubridai.com'
  },
  {
    title: 'Community Forum',
    description: 'Join discussions with other developers',
    icon: ExternalLink,
    url: 'https://community.qubridai.com'
  },
  {
    title: 'GitHub Repository',
    description: 'View code examples and contributions',
    icon: ExternalLink,
    url: 'https://github.com/qubridai'
  },
  {
    title: 'Support Tickets',
    description: 'Get help from our technical team',
    icon: ExternalLink,
    url: 'https://support.qubridai.com'
  }
];

export default function Docs() {
  return (
    <Layout>
      <div className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-heading-3xl text-primaryText mb-4">
              <FileText className="inline-block mr-3 text-neonRed" size={40} />
              Documentation
            </h1>
            <p className="text-body-lg text-mutedText max-w-3xl">
              Comprehensive guides, API documentation, and tutorials to help you build amazing AI applications with ANXPOD
            </p>
          </div>

          {/* Search */}
          <div className="mb-12">
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-mutedText" size={20} />
              <input
                type="text"
                placeholder="Search documentation..."
                className="w-full pl-12 pr-4 py-4 bg-charcoalSurface border border-gridDivider rounded-xl text-primaryText placeholder-mutedText focus:outline-none focus:border-neonRed text-lg"
              />
            </div>
          </div>

          {/* Documentation Categories */}
          <div className="mb-12">
            <h2 className="text-heading-2xl text-primaryText mb-6">Documentation Categories</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-system-lg">
              {docCategories.map((category) => (
                <div key={category.title}>
                  <Card className="h-full">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center`}>
                        <category.icon className="text-white" size={24} />
                      </div>
                      <span className="text-xs bg-neonRed/20 text-neonRed px-2 py-1 rounded-full">
                        {category.articles} articles
                      </span>
                    </div>
                    
                    <h3 className="text-heading-xl text-primaryText mb-2">{category.title}</h3>
                    <p className="text-mutedText text-body-sm mb-4 leading-relaxed">{category.description}</p>
                    
                    <Button variant="secondary" className="w-full">
                      Browse Articles
                    </Button>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Popular Articles */}
          <div className="mb-12">
            <h2 className="text-heading-2xl text-primaryText mb-6">Popular Articles</h2>
            <Card className="p-6">
              <div className="space-y-4">
                {popularArticles.map((article) => (
                  <div key={article.title} className="flex items-center justify-between p-4 bg-charcoalSurface rounded-lg">
                    <div className="flex-1">
                      <h4 className="text-primaryText font-medium mb-1">{article.title}</h4>
                      <div className="flex items-center space-x-4 text-sm text-mutedText">
                        <span className="bg-neonRed/20 text-neonRed px-2 py-1 rounded-full text-xs">
                          {article.category}
                        </span>
                        <span className="flex items-center">
                          <Clock size={12} className="mr-1" />
                          {article.readTime}
                        </span>
                        <span>{article.views}</span>
                        <span>Updated {article.lastUpdated}</span>
                      </div>
                    </div>
                    <ExternalLink className="text-mutedText" size={16} />
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Quick Links */}
          <div className="mb-12">
            <h2 className="text-heading-2xl text-primaryText mb-6">Quick Links</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-lg">
              {quickLinks.map((link) => (
                <div key={link.title}>
                  <Card className="h-full">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-primaryText font-medium">{link.title}</h4>
                      <link.icon className="text-mutedText" size={16} />
                    </div>
                    <p className="text-mutedText text-body-sm">{link.description}</p>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Help Section */}
          <div>
            <Card className="p-8 text-center">
              <h3 className="text-heading-2xl text-primaryText mb-4">Need More Help?</h3>
              <p className="text-mutedText mb-6 max-w-2xl mx-auto">
                Can't find what you're looking for? Our support team is here to help you get the most out of ANXPOD.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg">
                  Contact Support
                </Button>
                <Button variant="secondary" size="lg">
                  Join Community
                </Button>
                <Button variant="secondary" size="lg">
                  Schedule Demo
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
