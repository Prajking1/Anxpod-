import { BarChart3, Cpu, Zap, Clock, IndianRupee, TrendingUp, Activity, Server } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const stats = [
  {
    title: 'Total GPU Hours',
    value: '1,247',
    change: '+23%',
    trend: 'up',
    icon: Clock,
    color: 'from-neonRed to-laserRed'
  },
  {
    title: 'Active Instances',
    value: '12',
    change: '+2',
    trend: 'up',
    icon: Server,
    color: 'from-hotEmber to-crimson'
  },
  {
    title: 'Total Spend',
    value: '₹45,680',
    change: '+18%',
    trend: 'up',
    icon: IndianRupee,
    color: 'from-deepRuby to-bloodline'
  },
  {
    title: 'Models Deployed',
    value: '28',
    change: '+5',
    trend: 'up',
    icon: Cpu,
    color: 'from-crimson to-neonRed'
  }
];

const recentActivity = [
  {
    action: 'GPU Instance Deployed',
    model: 'NVIDIA H100',
    time: '2 hours ago',
    status: 'running',
    cost: '₹8,500/hr'
  },
  {
    action: 'Model Fine-tuning Started',
    model: 'Llama 3.1 8B',
    time: '4 hours ago',
    status: 'training',
    cost: '₹2,500/hr'
  },
  {
    action: 'Template Deployed',
    model: 'ComfyUI',
    time: '6 hours ago',
    status: 'completed',
    cost: '₹1,200/hr'
  },
  {
    action: 'RAG Application Created',
    model: 'Document Q&A System',
    time: '1 day ago',
    status: 'active',
    cost: '₹0.05/query'
  }
];

const usageData = [
  { name: 'Mon', hours: 12, cost: 15200 },
  { name: 'Tue', hours: 19, cost: 24800 },
  { name: 'Wed', hours: 8, cost: 10400 },
  { name: 'Thu', hours: 15, cost: 19500 },
  { name: 'Fri', hours: 22, cost: 28600 },
  { name: 'Sat', hours: 18, cost: 23400 },
  { name: 'Sun', hours: 14, cost: 18200 }
];

export default function Dashboard() {
  return (
    <Layout>
      <div className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-heading-3xl text-primaryText mb-4">
              <BarChart3 className="inline-block mr-3 text-neonRed" size={40} />
              Dashboard
            </h1>
            <p className="text-body-lg text-mutedText">
              Monitor your GPU usage, track spending, and manage your AI workloads
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-lg mb-8">
            {stats.map((stat) => (
              <div key={stat.title}>
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                      <stat.icon className="text-white" size={24} />
                    </div>
                    <div className={`text-xs px-2 py-1 rounded-full ${
                      stat.trend === 'up' ? 'bg-neonRed/20 text-neonRed' : 'bg-neonRed/20 text-neonRed'
                    }`}>
                      {stat.change}
                    </div>
                  </div>
                  
                  <h3 className="text-heading-2xl text-primaryText mb-1">{stat.value}</h3>
                  <p className="text-mutedText text-body-sm">{stat.title}</p>
                </Card>
              </div>
            ))}
          </div>

          {/* Usage Chart */}
          <div className="mb-8">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-heading-xl text-primaryText">Weekly Usage</h3>
                <Button variant="secondary" size="sm">
                  View Details
                </Button>
              </div>
              
              <div className="grid grid-cols-7 gap-4">
                {usageData.map((day) => (
                  <div key={day.name} className="text-center">
                    <div className="mb-2">
                      <div 
                        className="bg-primary-gradient rounded-lg mx-auto"
                        style={{ 
                          height: `${(day.hours / 25) * 120}px`,
                          width: '40px'
                        }}
                      ></div>
                    </div>
                    <p className="text-body-xs text-mutedText mb-1">{day.name}</p>
                    <p className="text-body-xs text-primaryText font-semibold">{day.hours}h</p>
                    <p className="text-body-xs text-mutedText">₹{(day.cost / 1000).toFixed(1)}k</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Recent Activity */}
          <div>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-heading-xl text-primaryText">Recent Activity</h3>
                <Button variant="secondary" size="sm">
                  View All
                </Button>
              </div>
              
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-charcoalSurface rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className={`w-3 h-3 rounded-full ${
                        activity.status === 'running' ? 'bg-neonRed' :
                        activity.status === 'training' ? 'bg-hotEmber' :
                        activity.status === 'completed' ? 'bg-laserRed' :
                        'bg-crimson'
                      }`}></div>
                      <div>
                        <p className="text-primaryText font-medium">{activity.action}</p>
                        <p className="text-mutedText text-body-sm">{activity.model}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-mutedText text-body-sm">{activity.time}</p>
                      <p className="text-neonRed text-body-sm font-semibold">{activity.cost}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="mt-8">
            <Card className="p-6">
              <h3 className="text-heading-xl text-primaryText mb-6">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-md">
                <Button className="flex items-center justify-center py-4">
                  <Cpu className="mr-2" size={20} />
                  Deploy GPU
                </Button>
                <Button variant="secondary" className="flex items-center justify-center py-4">
                  <Zap className="mr-2" size={20} />
                  Fine-tune Model
                </Button>
                <Button variant="secondary" className="flex items-center justify-center py-4">
                  <Activity className="mr-2" size={20} />
                  Monitor Usage
                </Button>
                <Button variant="secondary" className="flex items-center justify-center py-4">
                  <TrendingUp className="mr-2" size={20} />
                  View Analytics
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
