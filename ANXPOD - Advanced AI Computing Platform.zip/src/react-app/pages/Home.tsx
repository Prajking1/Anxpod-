import { Brain, Code, Zap, Settings, MessageSquare, Cpu, Image, Video, Languages, FileText, ChevronRight, ChevronLeft } from 'lucide-react';
import { useState, useRef } from 'react';
import Card from '../components/ui/Card';
import Layout from '../components/Layout';

const aiModelCategories = [
  {
    title: 'Open source Inferencing',
    description: 'Run and utilize the power of open-source AI models with ease, enabling fast and efficient inference for a wide range of applications.',
    icon: Code,
    gradient: 'from-neonRed to-crimson'
  },
  {
    title: 'HuggingFace Models',
    description: 'Effortlessly deploy any Hugging Face model on our platform with a single click, leveraging our powerful GPUs for fast and efficient inference.',
    icon: Brain,
    gradient: 'from-laserRed to-hotEmber'
  },
  {
    title: 'NVIDIA Inferencing Model',
    description: 'Deploy pre-optimized NVIDIA AI models with a single click and harness the power of NVIDIA GPUs for lightning-fast and efficient inference.',
    icon: Zap,
    gradient: 'from-hotEmber to-deepRuby'
  },
  {
    title: 'Model Tuning',
    description: 'Fine-tune pre-trained models with ease by selecting parameters, uploading your preprocessed data, and optimizing performance for your specific use case.',
    icon: Settings,
    gradient: 'from-crimson to-bloodline'
  },
  {
    title: 'RAG Applications',
    description: 'Build Retrieval-Augmented Generation applications that combine large language models with external knowledge bases for accurate responses.',
    icon: Brain,
    gradient: 'from-deepRuby to-neonRed'
  }
];

const aiCategories = [
  {
    title: 'Reasoning Models',
    description: 'Solve complex problems, draw logical inferences, and make informed decisions by mimicking human reasoning processes.',
    icon: Brain
  },
  {
    title: 'Text Generation',
    description: 'Create original and high-quality text, from stories and poems to articles and code, with advanced language models.',
    icon: MessageSquare
  },
  {
    title: 'Image Generation',
    description: 'Transform text descriptions into stunning and unique images with cutting-edge AI.',
    icon: Image
  },
  {
    title: 'Speech to Text',
    description: 'Accurately transcribe spoken language into written text, enabling seamless communication & accessibility.',
    icon: MessageSquare
  },
  {
    title: 'Code Generation',
    description: 'Generate high-quality code in multiple programming languages with AI-powered coding assistants.',
    icon: Code
  },
  {
    title: 'Video Generation',
    description: 'Create stunning videos from text descriptions using state-of-the-art AI video generation models.',
    icon: Video
  },
  {
    title: 'Audio Generation',
    description: 'Generate music, speech, and sound effects using advanced AI audio synthesis models.',
    icon: MessageSquare
  },
  {
    title: 'Object Detection',
    description: 'Identify and locate objects in images and videos with precision using computer vision models.',
    icon: Brain
  },
  {
    title: 'Language Translation',
    description: 'Translate text between multiple languages with high accuracy and natural fluency.',
    icon: Languages
  },
  {
    title: 'Document Analysis',
    description: 'Extract insights and information from documents, PDFs, and images using OCR and NLP.',
    icon: FileText
  }
];

const gpuCategories = [
  {
    title: 'NVIDIA H100',
    description: 'The industry-leading GPU for AI, delivering groundbreaking performance with cutting-edge Hopper architecture and Transformer Engine.',
    specs: '80GB HBM3, 3.35 TB/s',
    price: '₹8,500/hr'
  },
  {
    title: 'NVIDIA L40s',
    description: 'A powerful data center GPU designed for high-performance computing tasks, offering exceptional performance for AI training and inference.',
    specs: '48GB GDDR6, 864 GB/s',
    price: '₹4,200/hr'
  },
  {
    title: 'NVIDIA L4',
    description: 'A cost-effective and energy-efficient GPU designed for a wide range of AI and HPC workloads, ideal for entry-level AI deployments.',
    specs: '24GB GDDR6, 300 GB/s',
    price: '₹1,800/hr'
  },
  {
    title: 'NVIDIA T4',
    description: 'A versatile GPU designed for a balance of performance and efficiency, ideal for AI training, inference, and data science workloads.',
    specs: '16GB GDDR6, 320 GB/s',
    price: '₹1,200/hr'
  }
];

export default function Home() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  const itemsPerView = 4;
  const maxIndex = Math.max(0, aiCategories.length - itemsPerView);

  const scrollLeft = () => {
    const newIndex = Math.max(0, currentIndex - 1);
    setCurrentIndex(newIndex);
    
    if (scrollContainerRef.current) {
      const itemWidth = scrollContainerRef.current.children[0]?.getBoundingClientRect().width || 288;
      const gap = 16;
      scrollContainerRef.current.scrollTo({
        left: newIndex * (itemWidth + gap),
        behavior: 'smooth'
      });
    }
  };

  const scrollRight = () => {
    const newIndex = Math.min(maxIndex, currentIndex + 1);
    setCurrentIndex(newIndex);
    
    if (scrollContainerRef.current) {
      const itemWidth = scrollContainerRef.current.children[0]?.getBoundingClientRect().width || 288;
      const gap = 16;
      scrollContainerRef.current.scrollTo({
        left: newIndex * (itemWidth + gap),
        behavior: 'smooth'
      });
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-carbonBlack py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* AI Models Section */}
          <section className="mb-16">
            <div className="mb-8">
              <h2 className="text-heading-xl text-primaryText mb-2">
                I want to fine-tune and deploy AI Models | 5 Categories
              </h2>
              <p className="text-mutedText text-body-sm">
                Need GPU instance for your AI/ML application? No worries - select from a range of available NVIDIA GPU instances and AI packages & start programming or upload your own AI model and run on GPUs.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-system-md">
              {aiModelCategories.map((category) => (
                <div key={category.title}>
                  <Card className="h-full">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${category.gradient} flex items-center justify-center mb-3`}>
                      <category.icon className="text-white" size={20} />
                    </div>
                    <h3 className="text-heading-sm text-primaryText mb-2">{category.title}</h3>
                    <p className="text-mutedText text-body-xs leading-relaxed">{category.description}</p>
                  </Card>
                </div>
              ))}
            </div>
          </section>

          {/* AI Model Categories with Horizontal Scroll */}
          <section className="mb-16">
            <div className="mb-8">
              <h2 className="text-heading-xl text-primaryText mb-2">
                AI Model Category | 10 Categories
              </h2>
              <p className="text-mutedText text-body-sm">
                Generate, Demo and fine-tune open-source AI models to build your AI application
              </p>
            </div>

            <div className="relative">
              {/* Left Navigation Arrow */}
              {currentIndex > 0 && (
                <button
                  onClick={scrollLeft}
                  className="absolute left-0 top-1/2 transform -translate-y-1/2 z-10 w-10 h-10 bg-primary-gradient rounded-full flex items-center justify-center shadow-lg"
                >
                  <ChevronLeft className="text-white" size={20} />
                </button>
              )}
              
              {/* Scrollable Container */}
              <div 
                ref={scrollContainerRef}
                className="flex gap-system-md overflow-x-hidden pb-4 px-12"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                {aiCategories.map((category) => (
                  <div key={category.title} className="flex-shrink-0 w-72">
                    <Card className="h-full">
                      <div className="w-10 h-10 rounded-lg bg-primary-gradient flex items-center justify-center mb-3">
                        <category.icon className="text-white" size={20} />
                      </div>
                      <h3 className="text-heading-sm text-primaryText mb-2">{category.title}</h3>
                      <p className="text-mutedText text-body-xs leading-relaxed">{category.description}</p>
                    </Card>
                  </div>
                ))}
              </div>
              
              {/* Right Navigation Arrow */}
              {currentIndex < maxIndex && (
                <button
                  onClick={scrollRight}
                  className="absolute right-0 top-1/2 transform -translate-y-1/2 z-10 w-10 h-10 bg-primary-gradient rounded-full flex items-center justify-center shadow-lg"
                >
                  <ChevronRight className="text-white" size={20} />
                </button>
              )}
              
              {/* Progress Indicators */}
              <div className="flex justify-center mt-4 space-x-2">
                {Array.from({ length: maxIndex + 1 }, (_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setCurrentIndex(index);
                      if (scrollContainerRef.current) {
                        const itemWidth = 288;
                        const gap = 16;
                        scrollContainerRef.current.scrollTo({
                          left: index * (itemWidth + gap),
                          behavior: 'smooth'
                        });
                      }
                    }}
                    className={`w-2 h-2 rounded-full ${
                      index === currentIndex 
                        ? 'bg-primary-gradient' 
                        : 'bg-gridDivider'
                    }`}
                  />
                ))}
              </div>
            </div>
          </section>

          {/* GPU Section */}
          <section>
            <div className="mb-8">
              <h2 className="text-heading-xl text-primaryText mb-2">
                I want to access On-demand GPUs | 4 Categories
              </h2>
              <p className="text-mutedText text-body-sm">
                Generate, Demo and fine-tune open-source AI models to build your AI application
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-md">
              {gpuCategories.map((gpu) => (
                <div key={gpu.title}>
                  <Card className="h-full">
                    <div className="w-10 h-10 rounded-lg bg-primary-gradient flex items-center justify-center mb-3">
                      <Cpu className="text-white" size={20} />
                    </div>
                    <h3 className="text-heading-sm text-primaryText mb-2">{gpu.title}</h3>
                    <p className="text-mutedText text-body-xs mb-2 leading-relaxed">{gpu.description}</p>
                    <div className="text-body-xs text-mutedText mb-1">{gpu.specs}</div>
                    <div className="text-body-sm font-semibold text-neonRed">{gpu.price}</div>
                  </Card>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </Layout>
  );
}
