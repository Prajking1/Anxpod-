import { motion } from 'framer-motion';
import { Search, Filter, Star, Zap, Code, Image, MessageSquare, Video, Eye, Brain } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const models = [
  {
    name: 'DeepSeek-R1-Distill-1-Llama-8B',
    type: 'Reasoning Models',
    status: 'New',
    icon: Brain,
    price: '$0.02',
    description: 'Advanced reasoning model with 8B parameters'
  },
  {
    name: 'DeepSeek-R1-Distill-1-Qwen-7B',
    type: 'Reasoning Models',
    status: 'New',
    icon: Brain,
    price: '$0.02',
    description: 'Compact reasoning model optimized for efficiency'
  },
  {
    name: 'DeepSeek-R1-Distill-1-Qwen-14B',
    type: 'Reasoning Models',
    status: 'New',
    icon: Brain,
    price: '$0.02',
    description: 'Large-scale reasoning model with enhanced capabilities'
  },
  {
    name: 'DeepSeek-R1-Distill-1-Qwen-1.8B',
    type: 'Reasoning Models',
    status: 'New',
    icon: Brain,
    price: '$0.02',
    description: 'Lightweight reasoning model for fast inference'
  },
  {
    name: 'Stable-Diffusion-3.5-Large',
    type: 'Image Generation',
    status: 'Popular',
    icon: Image,
    price: '$0.05',
    description: 'Latest Stable Diffusion model with improved quality'
  },
  {
    name: 'Stable-Diffusion-3-Medium-Diffusers',
    type: 'Image Generation',
    status: '',
    icon: Image,
    price: '$0.05',
    description: 'Medium-sized SD3 model optimized for speed'
  },
  {
    name: 'Stable-Diffusion-xl-base-1.0',
    type: 'Image Generation',
    status: '',
    icon: Image,
    price: '$0.05',
    description: 'High-resolution image generation model'
  },
  {
    name: 'CodeQwen-1.5-7B-Chat',
    type: 'Code Generation',
    status: '',
    icon: Code,
    price: '$0.01',
    description: 'Conversational code generation model'
  },
  {
    name: 'Codegemma-7b-It',
    type: 'Code Generation',
    status: '',
    icon: Code,
    price: '$0.01',
    description: 'Google\'s instruction-tuned code model'
  },
  {
    name: 'CodeLlama-7b-Instruct-hf',
    type: 'Code Generation',
    status: '',
    icon: Code,
    price: '$0.01',
    description: 'Meta\'s instruction-following code model'
  },
  {
    name: 'Mistral-7B-Instruct-v0.3',
    type: 'Text Generation',
    status: '',
    icon: MessageSquare,
    price: '$0.01',
    description: 'Versatile text generation and chat model'
  },
  {
    name: 'Gemma-2B',
    type: 'Text Generation',
    status: '',
    icon: MessageSquare,
    price: '$0.01',
    description: 'Google\'s lightweight language model'
  },
  {
    name: 'Falcon-11B',
    type: 'Text Generation',
    status: '',
    icon: MessageSquare,
    price: '$0.01',
    description: 'Technology Innovation Institute\'s language model'
  },
  {
    name: 'Falcon-1B',
    type: 'Text Generation',
    status: '',
    icon: MessageSquare,
    price: '$0.01',
    description: 'Compact version of Falcon model'
  },
  {
    name: 'Whisper-small',
    type: 'Speech to Text',
    status: '',
    icon: MessageSquare,
    price: '$0.01',
    description: 'OpenAI\'s speech recognition model'
  },
  {
    name: 'AnimateDiff-Lightning-Anime',
    type: 'Video',
    status: '',
    icon: Video,
    price: '$0.05',
    description: 'Fast anime video generation model'
  },
  {
    name: 'AnimateDiff-Lightning-Realistic',
    type: 'Video',
    status: '',
    icon: Video,
    price: '$0.05',
    description: 'Realistic video generation with AnimateDiff'
  },
  {
    name: 'Yolo-v8',
    type: 'Object Detection',
    status: '',
    icon: Eye,
    price: '$0.01',
    description: 'State-of-the-art object detection model'
  },
  {
    name: 'PaliGemma-3b-pt-896c',
    type: 'Image to Text',
    status: '',
    icon: Eye,
    price: '$0.01',
    description: 'Vision-language model for image understanding'
  },
  {
    name: 'Phi-3-vision-128k-instruct',
    type: 'Image to Text',
    status: '',
    icon: Eye,
    price: '$0.01',
    description: 'Microsoft\'s multimodal instruction model'
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'New': return 'bg-green-500/20 text-green-400';
    case 'Popular': return 'bg-yellow-500/20 text-yellow-400';
    default: return '';
  }
};

const getTypeColor = (type: string) => {
  switch (type) {
    case 'Reasoning Models': return 'from-purple-500 to-pink-500';
    case 'Image Generation': return 'from-blue-500 to-cyan-500';
    case 'Code Generation': return 'from-green-500 to-emerald-500';
    case 'Text Generation': return 'from-orange-500 to-yellow-500';
    case 'Speech to Text': return 'from-red-500 to-rose-500';
    case 'Video': return 'from-violet-500 to-purple-500';
    case 'Object Detection': return 'from-indigo-500 to-blue-500';
    case 'Image to Text': return 'from-teal-500 to-cyan-500';
    default: return 'from-gray-500 to-gray-600';
  }
};

export default function OpenSourceInferencing() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <nav className="text-sm text-gray-400 mb-4">
              <span>Model Studio</span> <span className="mx-2">&gt;</span> <span className="text-primary-400">Open Source Inferencing</span>
            </nav>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Open Source Inferencing
            </h1>
            <p className="text-lg text-gray-300 max-w-4xl">
              Unlock a world of AI possibilities with reasoning models at $0.02 per request, image generation models at $0.05, and other AI models at just $0.01 - 500 requests for only $5!
            </p>
          </motion.div>

          {/* Search and Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 mb-8"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search models..."
                className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-primary-500"
              />
            </div>
            <Button variant="secondary" className="flex items-center">
              <Filter size={16} className="mr-2" />
              Filter
            </Button>
          </motion.div>

          {/* Models Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {models.map((model, index) => (
              <motion.div
                key={model.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getTypeColor(model.type)} flex items-center justify-center`}>
                      <model.icon className="text-white" size={20} />
                    </div>
                    {model.status && (
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(model.status)}`}>
                        {model.status}
                      </span>
                    )}
                  </div>
                  
                  <h3 className="text-sm font-semibold text-white mb-2 leading-tight">{model.name}</h3>
                  <p className="text-xs text-primary-400 mb-2">{model.type}</p>
                  <p className="text-xs text-gray-400 mb-4 leading-relaxed">{model.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-green-400">{model.price}/request</span>
                    <Button size="sm">
                      Deploy
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Pricing Info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12"
          >
            <Card className="max-w-4xl mx-auto">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-4">
                  <Zap className="inline-block mr-2 text-yellow-400" size={24} />
                  Special Launch Pricing
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-400 mb-2">$0.02</div>
                    <div className="text-sm text-gray-300">Reasoning Models</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-400 mb-2">$0.05</div>
                    <div className="text-sm text-gray-300">Image & Video Generation</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400 mb-2">$0.01</div>
                    <div className="text-sm text-gray-300">Other AI Models</div>
                  </div>
                </div>
                <p className="text-gray-400 mb-6">
                  Get started with 500 requests for just $5! Perfect for testing and small projects.
                </p>
                <Button size="lg">
                  <Star className="mr-2" size={16} />
                  Get 500 Requests for $5
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
