import { motion } from 'framer-motion';
import { Search, Database, Brain, FileText, Zap, Upload, Settings, MessageSquare, Globe } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const ragTemplates = [
  {
    name: 'Document Q&A System',
    description: 'Upload documents and create an intelligent question-answering system that understands context and provides accurate responses.',
    icon: FileText,
    features: ['PDF/Word support', 'Semantic search', 'Citation tracking'],
    price: '$0.05/query',
    setupTime: '5 minutes'
  },
  {
    name: 'Knowledge Base Assistant',
    description: 'Build a comprehensive knowledge base assistant that can answer questions from your company\'s documentation and policies.',
    icon: Database,
    features: ['Multi-document support', 'Contextual responses', 'Admin dashboard'],
    price: '$0.08/query',
    setupTime: '10 minutes'
  },
  {
    name: 'Customer Support Bot',
    description: 'Create an intelligent customer support bot that can handle complex queries using your support documentation.',
    icon: MessageSquare,
    features: ['Chat interface', 'Escalation handling', 'Analytics dashboard'],
    price: '$0.06/query',
    setupTime: '15 minutes'
  },
  {
    name: 'Research Assistant',
    description: 'Develop a research assistant that can analyze and synthesize information from multiple academic papers and documents.',
    icon: Brain,
    features: ['Multi-source analysis', 'Citation generation', 'Summary creation'],
    price: '$0.10/query',
    setupTime: '20 minutes'
  },
  {
    name: 'Code Documentation Helper',
    description: 'Build a system that understands your codebase and can answer questions about implementation, APIs, and best practices.',
    icon: Search,
    features: ['Code understanding', 'API documentation', 'Example generation'],
    price: '$0.07/query',
    setupTime: '12 minutes'
  },
  {
    name: 'Legal Document Analyzer',
    description: 'Create a legal assistant that can analyze contracts, policies, and legal documents to answer specific questions.',
    icon: FileText,
    features: ['Contract analysis', 'Compliance checking', 'Risk assessment'],
    price: '$0.12/query',
    setupTime: '25 minutes'
  }
];

const ragFeatures = [
  {
    title: 'Vector Database Integration',
    description: 'Built-in vector database with automatic indexing and similarity search',
    icon: Database,
    color: 'from-blue-500 to-cyan-500'
  },
  {
    title: 'Multiple LLM Support',
    description: 'Choose from GPT-4, Claude, Llama, and other leading language models',
    icon: Brain,
    color: 'from-purple-500 to-violet-500'
  },
  {
    title: 'Smart Chunking',
    description: 'Intelligent document chunking that preserves context and meaning',
    icon: FileText,
    color: 'from-green-500 to-emerald-500'
  },
  {
    title: 'Real-time Updates',
    description: 'Update your knowledge base in real-time with new documents',
    icon: Zap,
    color: 'from-orange-500 to-yellow-500'
  }
];

export default function RAG() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <nav className="text-sm text-gray-400 mb-4">
              <span>LLM Tools</span> <span className="mx-2">&gt;</span> 
              <span className="text-primary-400">RAG Applications</span>
            </nav>
            <h1 className="text-heading-3xl text-white mb-4">
              <Database className="inline-block mr-3 text-blue-400" size={40} />
              RAG Applications
            </h1>
            <p className="text-body-lg text-gray-300 max-w-4xl">
              Build Retrieval-Augmented Generation applications that combine the power of large language models with your own knowledge base. Create intelligent systems that can answer questions using your documents, databases, and content.
            </p>
          </motion.div>

          {/* RAG Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-12"
          >
            <h2 className="text-heading-xl text-white mb-6 text-center">RAG Platform Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-lg">
              {ragFeatures.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <Card className="h-full text-center">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${feature.color} flex items-center justify-center mx-auto mb-4`}>
                      <feature.icon className="text-white" size={24} />
                    </div>
                    <h3 className="text-heading-lg text-white mb-2">{feature.title}</h3>
                    <p className="text-gray-400 text-body-sm leading-relaxed">{feature.description}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* RAG Templates */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-12"
          >
            <h2 className="text-heading-xl text-white mb-6">Pre-built RAG Templates</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-system-lg">
              {ragTemplates.map((template, index) => (
                <motion.div
                  key={template.name}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <Card className="h-full">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center">
                        <template.icon className="text-white" size={24} />
                      </div>
                      <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded-full">
                        {template.setupTime}
                      </span>
                    </div>
                    
                    <h3 className="text-heading-xl text-white mb-2">{template.name}</h3>
                    <p className="text-gray-400 text-body-sm mb-4 leading-relaxed">{template.description}</p>
                    
                    <div className="mb-4">
                      <p className="text-body-sm text-gray-300 mb-2">Key Features:</p>
                      <ul className="space-y-1">
                        {template.features.map((feature, idx) => (
                          <li key={idx} className="text-body-xs text-gray-400 flex items-center">
                            <div className="w-1 h-1 bg-primary-400 rounded-full mr-2"></div>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm font-bold text-green-400">{template.price}</span>
                      <span className="text-xs text-gray-500">Setup: {template.setupTime}</span>
                    </div>
                    
                    <Button className="w-full">
                      Deploy Template
                    </Button>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* How it Works */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mb-12"
          >
            <Card className="max-w-6xl mx-auto">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-4">
                  <Zap className="inline-block mr-2 text-yellow-400" size={24} />
                  How RAG Works
                </h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Upload className="text-white" size={24} />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">1. Upload Documents</h4>
                  <p className="text-gray-400 text-sm">Upload your documents, PDFs, websites, or databases to create your knowledge base</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Settings className="text-white" size={24} />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">2. Configure & Index</h4>
                  <p className="text-gray-400 text-sm">Our system automatically processes and indexes your content using advanced embeddings</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-violet-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageSquare className="text-white" size={24} />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">3. Ask Questions</h4>
                  <p className="text-gray-400 text-sm">Get accurate, contextual answers backed by your specific knowledge base</p>
                </div>
              </div>
              
              <div className="text-center">
                <Button size="lg" className="mr-4">
                  <Database className="mr-2" size={16} />
                  Build RAG Application
                </Button>
                <Button variant="secondary" size="lg">
                  <Globe className="mr-2" size={16} />
                  View Live Demo
                </Button>
              </div>
            </Card>
          </motion.div>

          {/* Pricing */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mt-12"
          >
            <Card className="max-w-4xl mx-auto">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-4">Simple, Usage-Based Pricing</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400 mb-2">$0.05 - $0.12</div>
                    <div className="text-sm text-gray-300">Per Query</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-400 mb-2">Free</div>
                    <div className="text-sm text-gray-300">Document Storage</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-400 mb-2">24/7</div>
                    <div className="text-sm text-gray-300">Support</div>
                  </div>
                </div>
                <p className="text-gray-400 mb-6">
                  Only pay for what you use. No setup fees, no monthly minimums. Start with our free tier and scale as you grow.
                </p>
                <Button size="lg">
                  Start Building for Free
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
