import { Upload, Settings, Zap, BarChart3, Code, Database, Brain, CheckCircle, PlayCircle, Monitor } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Layout from '../components/Layout';

const fineTuningOptions = [
  {
    name: 'Llama 3.1 8B',
    type: 'Language Model',
    baseModel: 'Meta Llama 3.1',
    parameters: '8B',
    price: '$2.50/hour',
    estimatedTime: '2-4 hours',
    icon: Brain,
    description: 'Fine-tune Meta\'s latest language model for your specific use case'
  },
  {
    name: 'Llama 3.1 70B',
    type: 'Language Model',
    baseModel: 'Meta Llama 3.1',
    parameters: '70B',
    price: '$8.00/hour',
    estimatedTime: '6-12 hours',
    icon: Brain,
    description: 'High-capacity model for complex reasoning and specialized tasks'
  },
  {
    name: 'Code Llama 7B',
    type: 'Code Generation',
    baseModel: 'Meta Code Llama',
    parameters: '7B',
    price: '$2.00/hour',
    estimatedTime: '1-3 hours',
    icon: Code,
    description: 'Specialized for code generation and programming tasks'
  },
  {
    name: 'Mistral 7B',
    type: 'Language Model',
    baseModel: 'Mistral AI',
    parameters: '7B',
    price: '$1.80/hour',
    estimatedTime: '2-4 hours',
    icon: Brain,
    description: 'Efficient and high-performing model for general tasks'
  },
  {
    name: 'Stable Diffusion XL',
    type: 'Image Generation',
    baseModel: 'Stability AI',
    parameters: '3.5B',
    price: '$3.20/hour',
    estimatedTime: '3-6 hours',
    icon: Database,
    description: 'Fine-tune for custom image generation styles and concepts'
  },
  {
    name: 'BERT Large',
    type: 'Text Classification',
    baseModel: 'Google BERT',
    parameters: '340M',
    price: '$1.20/hour',
    estimatedTime: '1-2 hours',
    icon: Brain,
    description: 'Perfect for text classification and NLP tasks'
  }
];

const tuningSteps = [
  {
    step: 1,
    title: 'Select Base Model',
    description: 'Choose from our collection of pre-trained models',
    icon: Database,
    color: 'from-neonRed to-laserRed'
  },
  {
    step: 2,
    title: 'Upload Training Data',
    description: 'Upload your dataset in supported formats (JSON, CSV, TXT)',
    icon: Upload,
    color: 'from-hotEmber to-crimson'
  },
  {
    step: 3,
    title: 'Configure Parameters',
    description: 'Set learning rate, batch size, epochs, and other hyperparameters',
    icon: Settings,
    color: 'from-deepRuby to-bloodline'
  },
  {
    step: 4,
    title: 'Start Training',
    description: 'Monitor progress with real-time metrics and logs',
    icon: PlayCircle,
    color: 'from-crimson to-neonRed'
  }
];

export default function FineTuning() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <nav className="text-sm text-mutedText mb-4">
              <span>LLM Tools</span> <span className="mx-2">&gt;</span> 
              <span className="text-neonRed">Fine Tuning</span>
            </nav>
            <h1 className="text-heading-3xl text-primaryText mb-4">
              <Settings className="inline-block mr-3 text-neonRed" size={40} />
              AI Model Fine-Tuning
            </h1>
            <p className="text-body-lg text-mutedText max-w-4xl">
              Customize pre-trained models for your specific use case. Upload your data, configure parameters, and create specialized AI models with our high-performance GPU infrastructure.
            </p>
          </div>

          {/* Process Steps */}
          <div className="mb-12">
            <h2 className="text-heading-2xl text-primaryText mb-6 text-center">Fine-Tuning Process</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-lg">
              {tuningSteps.map((step) => (
                <div key={step.step}>
                  <Card className="h-full text-center">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center mx-auto mb-4`}>
                      <step.icon className="text-white" size={24} />
                    </div>
                    <div className="text-body-sm bg-neonRed/20 text-neonRed px-3 py-1 rounded-full inline-block mb-3">
                      Step {step.step}
                    </div>
                    <h3 className="text-heading-lg text-primaryText mb-2">{step.title}</h3>
                    <p className="text-mutedText text-body-sm leading-relaxed">{step.description}</p>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Available Models */}
          <div className="mb-12">
            <h2 className="text-heading-2xl text-primaryText mb-6">Available Models for Fine-Tuning</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-system-lg">
              {fineTuningOptions.map((model) => (
                <div key={model.name}>
                  <Card className="h-full">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-lg bg-primary-gradient flex items-center justify-center">
                        <model.icon className="text-white" size={24} />
                      </div>
                      <span className="text-xs bg-neonRed/20 text-neonRed px-2 py-1 rounded-full">
                        {model.parameters}
                      </span>
                    </div>
                    
                    <h3 className="text-heading-xl text-primaryText mb-1">{model.name}</h3>
                    <p className="text-neonRed text-body-sm mb-2">{model.type}</p>
                    <p className="text-mutedText text-body-sm mb-4 leading-relaxed">{model.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-mutedText">Base Model:</span>
                        <span className="text-primaryText">{model.baseModel}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-mutedText">Est. Time:</span>
                        <span className="text-primaryText">{model.estimatedTime}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-mutedText">Price:</span>
                        <span className="text-neonRed font-semibold">{model.price}</span>
                      </div>
                    </div>
                    
                    <Button className="w-full">
                      Start Fine-Tuning
                    </Button>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Features */}
          <div className="mt-12">
            <Card className="max-w-6xl mx-auto">
              <div className="text-center mb-8">
                <h3 className="text-heading-2xl text-primaryText mb-4">
                  <Zap className="inline-block mr-2 text-neonRed" size={24} />
                  Advanced Fine-Tuning Features
                </h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-system-lg mb-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-neonRed to-laserRed rounded-full flex items-center justify-center mx-auto mb-4">
                    <Monitor className="text-white" size={24} />
                  </div>
                  <h4 className="text-heading-lg text-primaryText mb-2">Real-time Monitoring</h4>
                  <p className="text-mutedText text-body-sm">Track training progress with live metrics, loss curves, and validation scores</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-hotEmber to-crimson rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="text-white" size={24} />
                  </div>
                  <h4 className="text-heading-lg text-primaryText mb-2">Automatic Checkpoints</h4>
                  <p className="text-mutedText text-body-sm">Auto-save model checkpoints and resume training from any point</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-deepRuby to-bloodline rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="text-white" size={24} />
                  </div>
                  <h4 className="text-heading-lg text-primaryText mb-2">Hyperparameter Tuning</h4>
                  <p className="text-mutedText text-body-sm">Automated hyperparameter optimization for optimal model performance</p>
                </div>
              </div>
              
              <div className="text-center">
                <Button size="lg" className="mr-4">
                  <PlayCircle className="mr-2" size={16} />
                  Start Fine-Tuning
                </Button>
                <Button variant="secondary" size="lg">
                  View Documentation
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
