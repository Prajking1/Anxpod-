import { motion } from 'framer-motion';
import { Check, Zap, Star, IndianRupee, Cpu, Brain, Database } from 'lucide-react';
import { Link } from 'react-router';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Layout from '../components/Layout';

const pricingPlans = [
  {
    name: 'Starter',
    price: '₹0',
    period: 'Free Forever',
    description: 'Perfect for getting started with AI development',
    specs: 'T4 GPU • 16GB RAM • 200GB NVMe SSD',
    features: [
      '₹500 free credits',
      '2 hours GPU access monthly',
      'Basic AI/ML templates',
      'Community support',
      'Up to 3 projects',
      'Standard bandwidth'
    ],
    popular: false,
    cta: 'Get Started Free'
  },
  {
    name: 'Developer',
    price: '₹3,999',
    period: '/month',
    description: 'Ideal for individual developers and small projects',
    specs: '1x A100 GPU • 64GB RAM • 600GB NVMe SSD',
    features: [
      '100 GPU hours included',
      'High-speed NVMe storage',
      'All AI/ML templates',
      'Priority email support',
      'Unlimited projects',
      'Advanced monitoring',
      'REST API access'
    ],
    popular: true,
    cta: 'Start 7-Day Trial'
  },
  {
    name: 'Pro',
    price: '₹8,999',
    period: '/month',
    description: 'Built for teams and production workloads',
    specs: '2x A100 GPU • 128GB RAM • 1.2TB NVMe SSD',
    features: [
      '200 GPU hours included',
      'Multi-GPU instances',
      'Team collaboration tools',
      'Custom environment templates',
      'Dedicated support channel',
      'Advanced analytics & monitoring',
      'Load balancing',
      'Auto-scaling'
    ],
    popular: false,
    cta: 'Start Trial'
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'Contact Us',
    description: 'Tailored solutions for large organizations',
    specs: 'Custom GPU clusters • Dedicated resources',
    features: [
      'Unlimited GPU hours',
      'Dedicated infrastructure',
      'On-premise deployment options',
      'White-label solutions',
      '24/7 phone & chat support',
      'Custom integrations & APIs',
      'SOC2 & ISO compliance',
      'Training & onboarding'
    ],
    popular: false,
    cta: 'Contact Sales'
  }
];

const gpuPricing = [
  {
    name: 'NVIDIA T4',
    specs: 'T4 GPU • 16GB VRAM • 32GB RAM • 400GB NVMe SSD',
    price: '₹1.2',
    useCase: 'Development & Testing',
    popular: false
  },
  {
    name: 'NVIDIA L4',
    specs: 'L4 GPU • 24GB VRAM • 48GB RAM • 500GB NVMe SSD',
    price: '₹1.8',
    useCase: 'Inference & Light Training',
    popular: false
  },
  {
    name: 'NVIDIA A100',
    specs: 'A100 GPU • 80GB VRAM • 64GB RAM • 600GB NVMe SSD',
    price: '₹6.2',
    useCase: 'Heavy Training & Research',
    popular: true
  },
  {
    name: 'NVIDIA H100',
    specs: 'H100 GPU • 80GB VRAM • 128GB RAM • 1TB NVMe SSD',
    price: '₹8.5',
    useCase: 'LLM Training & Enterprise',
    popular: false
  }
];

const features = [
  {
    category: 'GPU Computing',
    items: [
      'Instant GPU provisioning',
      'Auto-scaling infrastructure',
      'Pre-configured environments',
      'Persistent storage'
    ]
  },
  {
    category: 'AI/ML Tools',
    items: [
      'Model fine-tuning',
      'RAG applications',
      'Inference endpoints',
      'Model versioning'
    ]
  },
  {
    category: 'Platform',
    items: [
      'Web-based interface',
      'REST API access',
      'Real-time monitoring',
      'Usage analytics'
    ]
  }
];

export default function Pricing() {
  return (
    <Layout>
      <div className="min-h-screen py-8 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-heading-3xl text-white mb-4">
              <IndianRupee className="inline-block mr-3 text-green-400" size={48} />
              Simple, Transparent Pricing
            </h1>
            <p className="text-body-lg text-gray-300 max-w-3xl mx-auto">
              Choose the perfect plan for your AI development needs. Start free and scale as you grow.
              <br />
              <span className="text-body-sm text-gray-400 mt-2 block">All prices in Indian Rupees (₹) • GST applicable</span>
            </p>
          </motion.div>

          {/* Pricing Plans */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-system-lg mb-16">
            {pricingPlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative"
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 z-10">
                    <span className="bg-gradient-to-r from-primary-500 to-primary-800 text-white text-xs font-semibold px-4 py-1 rounded-full flex items-center">
                      <Star size={12} className="mr-1" />
                      Most Popular
                    </span>
                  </div>
                )}
                
                <Card className="h-full">
                  <div className="text-center mb-6">
                    <h3 className="text-heading-xl text-white mb-2">{plan.name}</h3>
                    <div className="mb-2">
                      <span className="text-3xl font-bold text-white">{plan.price}</span>
                      <span className="text-gray-400 text-body-sm ml-1">{plan.period}</span>
                    </div>
                    <p className="text-gray-400 text-body-sm mb-3">{plan.description}</p>
                    {plan.specs && (
                      <div className="bg-purple-900/20 border border-purple-500/20 rounded-lg p-3 mb-4">
                        <p className="text-purple-300 text-body-xs font-medium">{plan.specs}</p>
                      </div>
                    )}
                  </div>
                  
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start text-sm">
                        <Check className="text-green-400 mr-2 mt-0.5 flex-shrink-0" size={16} />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full ${plan.popular ? '' : 'bg-white/10 hover:bg-white/20'}`}
                    variant={plan.popular ? 'primary' : 'secondary'}
                  >
                    {plan.cta}
                  </Button>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* GPU Pricing */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mb-16"
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">
                <Cpu className="inline-block mr-3 text-blue-400" size={32} />
                Pay-Per-Hour GPU Pricing
              </h2>
              <p className="text-lg text-gray-300">
                Only pay for what you use with our flexible hourly pricing
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {gpuPricing.map((gpu, index) => (
                <motion.div
                  key={gpu.name}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="relative"
                >
                  {gpu.popular && (
                    <div className="absolute -top-2 right-2 z-10">
                      <span className="bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs font-semibold px-2 py-1 rounded-full">
                        Popular
                      </span>
                    </div>
                  )}
                  <Card className="text-center h-full">
                    <div className={`w-12 h-12 bg-gradient-to-br ${
                      gpu.popular ? 'from-green-500 to-emerald-600' : 'from-blue-500 to-cyan-600'
                    } rounded-lg flex items-center justify-center mx-auto mb-4`}>
                      <Cpu className="text-white" size={24} />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-3">{gpu.name}</h3>
                    <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-3 mb-4">
                      <p className="text-gray-300 text-xs leading-relaxed">{gpu.specs}</p>
                    </div>
                    <div className="text-2xl font-bold text-green-400 mb-2">{gpu.price}/hour</div>
                    <p className="text-gray-300 text-sm">{gpu.useCase}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Features Comparison */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="mb-16"
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">What's Included</h2>
              <p className="text-lg text-gray-300">
                All plans include access to our comprehensive AI development platform
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((category, index) => (
                <motion.div
                  key={category.category}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                >
                  <Card className="h-full">
                    <div className="mb-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${
                        index === 0 ? 'from-green-500 to-emerald-500' :
                        index === 1 ? 'from-primary-500 to-primary-700' :
                        'from-blue-500 to-cyan-500'
                      } flex items-center justify-center mb-3`}>
                        {index === 0 ? <Cpu className="text-white" size={24} /> :
                         index === 1 ? <Brain className="text-white" size={24} /> :
                         <Database className="text-white" size={24} />}
                      </div>
                      <h3 className="text-lg font-bold text-white">{category.category}</h3>
                    </div>
                    
                    <ul className="space-y-2">
                      {category.items.map((item, idx) => (
                        <li key={idx} className="flex items-start text-sm">
                          <Check className="text-green-400 mr-2 mt-0.5 flex-shrink-0" size={14} />
                          <span className="text-gray-300">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
          >
            <Card className="p-8 text-center">
              <h3 className="text-2xl font-bold text-white mb-4">
                <Zap className="inline-block mr-2 text-yellow-400" size={28} />
                Ready to Get Started?
              </h3>
              <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
                Join thousands of developers and researchers using ANXPOD to build the next generation of AI applications.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
                <Link to="/request-access">
                  <Button size="lg">
                    Start Free Trial
                  </Button>
                </Link>
                <Button variant="secondary" size="lg">
                  Contact Sales
                </Button>
              </div>
              
              {/* GST Note */}
              <div className="border-t border-gray-700/50 pt-6 mt-6">
                <p className="text-gray-500 text-xs">
                  * All prices are in Indian Rupees (₹) and exclude 18% GST as applicable.
                  <br />
                  Prices may vary based on usage and additional services.
                </p>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
